﻿progetto-SNAPS © 2020/2024 AntoPISA
MAME Support Files v0.262
-----------------------------------

The following files have been updated in this MAME cycle:

- Category pack
- CatVer pack
- Command,dat
- Languages.ini
- MESSinfo.dat
- renameSET.dat
- Series.ini
- Version pack

Home-page: https://www.progettosnaps.net/support/