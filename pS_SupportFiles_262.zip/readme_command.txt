MAME COMMAND.dat 0.262       (Feb  9, 2023)
(C) Fabricio Coroquer www.progettoSNAPS.net
Revised and distributed by: AntoPISA
-------------------------------------------
This file, which lists the various commands of many arcade games,
created and maintained by Procyon and Fabricio2012,  and now been
revised, updated and maintained by Fabricio Coroquer and distributed AntoPISA.


WhatsNew:
---------
1.18 0.262 2024/02/02/09: From today you can also find the files here: https://github.com/AntoPISA/MAME_SupportFiles
1.17 0.262 2024/02/05: Fabricio2012 has added 1 new item.
1.16 0.261 2023/12/03: Fabricio2012 has updated 1 item. I will add some new games in next year.
1.15 0.255 2023/06/06: Fabricio2012 has added 1 new item.
1.14 0.254 2023/05/01: Fabricio2012 has updated 2 items and added 14 new items.
1.13 0.253 2023/04/07: Fabricio2012 has updated and/or added 20 items.
1.12 0.252 2023/02/26: Fabricio2012 added 3 new items.
1.11 0.251 2023/01/13: Fabricio2012 added 1 items.
1.10 0.249 2022/10/31: 1 item removed (primrageo).
1.09 0.248 2022/10/02: Fabricio2012 added 11 items and 36 updated.
1.08 0.247 2022/09/03: Thanks to Fabricio2012 2 items have been added.
1.07 0.246 2022/08/03: Thanks to Fabricio2012 9 items have been added and 35 updated.
1.06 0.244 2022/06/06: Thanks to Fabricio2012 5 items have been added and 185 updated.
1.05 0.242 2022/04/04: Thanks to Fabricio2012 108 items have been added and 72 are updated.
1.04 0.230 2021/04/17: Fixed some files (eliminated the presence of BOMs that created problems). Thanks to Saknet and Robbbert.
1.03 0.230 2021/04/02: Thanks to Fabricio2012 28 items have been added and 21 are fixed.
1.02 0.229 2021/02/25: Thanks to Fabricio2012 14 items have been added and others are fixed (read "WhatsNew [2020-2021].txt" for more details).
1.01 0.216 2019/11/28: Thanks to Fabricio2012 60 items have been added and others are fixed.
1.00 0.215 2019/02/11: Thanks to Fabricio2012 various items have been removed and other added/fixed.
0.09 0.205 2018/12/27: Renamed (sfex2p) to (sfex2pu) and (sftmj) to (sftmj112); 2 items added.
0.08 0.204 2018/11/29: Renamed (xmcotaar1) to (xmcotaar2); 38 items added.
0.07 0.188 2017/07/29: Renamed (kinst2k3) to (kinst2uk); removed (kinst13), (kinst14), (kinst210), (kinst211), (kinst213), (kinst2k4) and (kinstp).
0.06 0.187 2017/07/25: Added command.ini file.
0.05 0.187 2017/07/01: Added 2 items. Renamed (ehrgeizaa) to (ehrgeiz), (souledgeaa) to (souledgea),  (tekkenab) to (tekkenb), (tekken2aa) to (tekken2a), (tekken2ab) to (tekken2b), (tekken3) to (tekken3je1), (tekken3aa) to (tekken3a), (tekken3ab) to (tekken3b), (tekken3ae) to (tekken3), (tektagtac) to (tektagt) and (tektagtac1) to (tektagtc1).
0.04 0.183 2017/06/03: Today, with the consent of Procyon, this version of the file is the official one!
0.03 0.183 2017/02/26: 6 items added, 3 renamed, 4 fixed and 1 deleted.
0.02 0.172 2016/04/03: Minor fixes.
0.01 0.171 2016/03/15: First version (pre-release).


How to use:
-----------
The file it must be placed in the "\dats" folder of your MAME.


(C) 2016/2024 AntoPISA, Procyon and Fabricio2012