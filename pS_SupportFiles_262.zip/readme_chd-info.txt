MAME CHD-Info v0.262
progetto-SNAPS � 2016/2024 AntoPISA
===================================

Home-page: https://www.progettosnaps.net/chdinfo/

In this package you can find these ini files:
- SL folder: All SL CHD dats.
- diff folder: Differences between the last two CHD dat available.
- CHD-Info_VER.txt: With detailed information on all - CHD supported by MAME.
- CHD_diff_OLD_NEW.dat: With the changes between the last two released versions.
- MAME_CHD_VER.dat: With dat comprising only the CHD.

Credits:
--------
- Thanks to Armax for "DFC: Dat File Creator".
- Thanks to Guy Peters for the "CHDmanFE" tool.
- Thanks to motoschifo for the great help provided for the web version of this file.
- Thanks to MASH for periodic checks.


� 2016/2024 AntoPISA