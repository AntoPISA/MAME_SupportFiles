MAME SERIES.ini 0.262 (Feb  9, 2024)
(C) AntoPISA   www.progettoSNAPS.net
==================================== 

Home-page:          https://www.progettosnaps.net/series/
GitHub repository:  https://github.com/AntoPISA/MAME_SupportFiles

A project started by PaolinoF15 and maintained by Xain D'Sleena (since version 0.143);  from 0.144 updated by AntoPISA.
From 0.162 version, the file deals only for arcade sets. From the 0.177 version it is helped by a tool for the creation
and verification of the .ini files, created by motoschifo. Many thanks to Alexis B. of https://www.arcade-history.com/. 


WhatsNew 0.262 (09.02.2024) (712 supported Series):
=====================================================
Series RENAMED (24): (blkrhino) to (blkrhinonz), (bumblbugql) to (bumblbugq), (chariotcv) to (chariotcpe), (chickna5ql) to (chickna5q), (dolphntrql) to (dolphntrq), (eforest) to (eforestu), (eforesta) to (eforest), (eforestb) to (eforestnz), (galpansu) to (galpansua), (hthero) to (htheroj), (indrema5ql) to (indrema5q), (jojoba) to (jojobar1), (jojobaj) to (jojobajr1), (jojobajr1) to (jojobajr2), (jojoban) to (jojobanr1), (jojobane) to (jojobaner1), (jojobaner1) to (jojobaner2), (jojobanr1) to (jojobanr2), (jojobar1) to (jojobar2), (pbss330) to (pbss330a), (qnileql) to (qnileq), (qnilev) to (qnilepe), (reelrockql) to (reelrockq) and (tekken2) to (tekken2ud).
Series UPDATED (15): Aristocrat MK Hardware, Black Rhino, Cherry Master, Crime Fighters, Cruis'n USA, Dolphin Treasure, Enchanted Forest, Gals Panic, Hat Trick Hero, JoJo's Bizarre Adventure, Mahjong Gakuensai, Operation Wolf, Pit Boss, Reelin-n-Rockin and Tekken.
Series ADDED (3): Altair, Euro Champ '92 and Treasures of the Inca.


WhatsNew 0.261 (05.12.2023) (709 supported Series):
=====================================================
Series RENAMED (1): (Cosmic) to (Cosmic Monsters).
Series UPDATED (11): Astro Fighter, BombJack, Cosmic Monsters, Pac-Man, Phoenix, Pole Position, Rally X, Scramble, Sea Wolf, Stadium Hero and Track & Field.

WhatsNew 0.260 (01.11.2023) (709 supported Series):
=====================================================
Series UPDATED (3): Gunforce, Pit Boss and Trivia ? Whiz.
Items RENAMED (7): (trvwz3h) to (trvwz3b), (trvwz3ha) to (trvwz3), (trvwz4) to (trvwz4v), (trvwz4a) to (trvwz4va), (trvwzh) to (trvwz), (trvwzha) to (trvwza) and (trvwzhb) to (trvwzb).

WhatsNew 0.259 (05.10.2023) (709 supported Series):
=====================================================
Series UPDATED (5): beatmania, Big Pro Wrestling!, Danger Zone, Super Volleyball and Zero Team.

WhatsNew 0.258 (05.09.2023) (709 supported Series):
=====================================================
Series ADDED (1): Makaimura.
Series UPDATED (8): Deal Or No Deal, Final Fight, Ghosts'n Goblins, Killer Instinct, Player's Edge, Racing Jam, Snow Bros. and The Legend of Kage.
Items RENAMED (1): (lkageoo) to (lkageo2).

WhatsNew 0.257 (03.08.2023) (708 supported Series):
=====================================================
Series UPDATED (6): Bare Knuckle, Frogger, Mortal Kombat, Player's Edge, Print Club and Zero Team.
Items RENAMED (1): (nzeroteama) to (nzeroteamb).

WhatsNew 0.256 (06.07.2023) (708 supported Series):
=====================================================
Series UPDATED (8): Amidar, Arkanoid, Pac-Man, Phoenix, Player's Edge, Raiden, Sprint, Taiko no Tatsujin and Tecmo World Cup.
Items RENAMED (14): (pepp0042) to (pepp0042a), (pepp0042a) to (pepp0042b), (pepp0083) to (pepp0083a), (pepp0420) to (pepp0420a), (pepp0430) to (pepp0430a), (pepp0459) to (pepp0459a), (pepp0508) to (pepp0508a), (pepp0540) to (pepp0540a), (pepp0750) to (pepp0750a), (puckpkmn) to (puckpkmnb), (puckpkmna) to (jingling), (raiden) to (raidenj), (raidena) to (raiden) and (sprint4) to (sprint4b).

WhatsNew 0.255 (09.06.2023) (708 supported Series):
=====================================================
Series UPDATED (9): Ace Driver, DrumMania, Galaxian, Guitar Freaks, Percussion Freaks, Pop'n Music, Street Fighter, Taiko no Tatsujin and WWF Superstars.
Items RENAMED (2): (popnanm) to (popnanma) and (popnanm2) to (popnanm2a).
Items REMOVED (6): (drmn10ma), (drmn9mb), (gtfrk10mb), (gtfrk11ma), (pcnfrk10ma) and (pcnfrk9ma).

WhatsNew 0.254 (04.05.2023) (708 supported Series):
=====================================================
Series UPDATED (8): Aristocrat MK Hardware, F-1 Grand Prix, Mr. Driller, Reelin-n-Rockin, Space Invaders, Strikers 1945, Taiko no Tatsujin and World Club Champion Football.
Series NEW (3): GAHAHA Ippatsudou, Medal no Tatsujin and Soreike! Anpanman.
Items RENAMED (17): (50lionsm) to (50lionsa), (5koipp) to (5koi), (antcleom) to (antcleoa), (crysprim) to (cryspria), (csdm) to (csda), (dimeye) to (dimeyeu), (f1gpb) to (f1gpbl), (gldgong) to (gldgongu), (holdrma) to (holdrma6), (mrdrilr2) to (mrdrilr2j), (mrdrilrga) to (mrdrilrg), (mrdrlr2a) to (mrdrilr2), (silkrda6) to (silkrda6u), (thaiprncm) to (thaiprnca), (wheregldm) to (whereglda), (wingoly) to (wingolyu) and (wwaysm) to (wwaysa).
Items REMOVED (1): (mrdrilrg).

WhatsNew 0.253 (08.04.2023) (705 supported Series):
=====================================================
Series UPDATED (5): Gals Panic, Jockey Club, Multi Game, The Pit and WWF Superstars.
Series NEW (1): Hot Body.

WhatsNew 0.252 (06.03.2023) (704 supported Series):
=====================================================
Series UPDATED (6): Galaxian, Moon Cresta, Pac-Man, Raiden, Soul Edge and Tekken.
Items RENAMED (2): (soulclbraa) to (soulclbra) and (soulclbrwb) to (soulclbrab).

WhatsNew 0.251 (05.01.2023) (704 supported Series):
=====================================================
Series NEW (1): Racing Jam.
Series UPDATED (4): Final Fight, Pocket Gal,  Power Instinct and Thrill Drive.
Items RENAMED (4): (pwrinst2) to (pwrinst2a),(thrilld) to (thrilldja), (thrilldb) to (thrilldbja) and (thrilldbu) to (thrilldgeu).

WhatsNew 0.250 (07.12.2022) (703 supported Series):
=====================================================
Series UPDATED (8): Cherry Master, Cross Pang, Gradius, Ibara, Quizard, Silent Scope, Trivia and Trivial Pursuit.
Items RENAMED (8): (ibara) to (ibarao), (sscope2b) to (sscope2ubvd1), (sscope2c) to (sscope2ucvd1), (sscopea) to (sscopeua), (sscopeb) to (sscopeub), (sscopec) to (sscopeuc), (sscoped) to (sscopevd2) and (trivia12) to (triviag1a).

WhatsNew 0.249 (05.11.2022) (703 supported Series):
=====================================================
Series NEW (1): Dynablaster.
Series UPDATED (10): Arm Champs, beatmania, Bosconian, Club Kart, Gun Dealer, Pit Boss, Primal Rage, Street Fighter, Twin Cobra and X-Men.
Items RENAMED (7): (bosco) to (bosco3), (boscoo) to (bosco1), (boscoo2) to (bosco1o), (ktiger) to (ktigera), (pitbossm) to (pitbossma), (pitbossma) to (pitbossmb) and (primrage) to (primrageo).

WhatsNew 0.248 (06.10.2022) (702 supported Series):
=====================================================
Series UPDATED (9): Dance Dance Revolution, Dance Maniax, DrumMania, Golden Tee, Guitar Freaks, Mario Bros., Percussion Freaks, Soul Edge and Strikers 1945.
Items RENAMED (7): (ddr2ml) to (ddr2mla), (drmn9m) to (drmn9ma), (gtgt) to (gtgt20), (gtgt1) to (gtgt10), (pcnfrk10m) to (pcnfrk10ma), (pcnfrk9m) to (pcnfrk9ma) and (sblast2ba) to (tmntmwb).
Items REMOVED (1): (sfrush).

WhatsNew 0.247 (09.09.2022) (702 supported Series):
=====================================================
Series NEW (1): Toy's March.
Series UPDATED (9): Battle Garegga, Crazy Kong, Dance Dance Revolution, DJ Boy, DrumMania, Pac-Man, Silent Scope, Thrill Drive and Trivia Master.
Items RENAMED (16): (cmtetrsa) to (cmtetrisa), (cmtetrsa) to (cmtetrisa), (cmtetrsb) to (cmtetrisb), (cmtetrsb) to (cmtetrisb), (cmtetrsc) to (cmtetrisc), (cmtetrsc) to (cmtetrisc), (cmtetrsd) to (cmtetrisd), (cmtetrsd) to (cmtetrisd), (magicarda) to (magicrd1a), (magicardb) to (magicrd1b), (magicarde) to (magicrde), (magicardea) to (magicrdea), (magicardeb) to (magicrdec), (magicardec) to (magicrdj), (magicardj) to (magicrdja) and (pjustic) to (pjustica).

WhatsNew 0.246 (06.08.2022) (701 supported Series):
=====================================================
Series UPDATED (5): Cherry Master, Crazy Climber, Derby Owners Club, Tetris and Thunder & Lightning.

WhatsNew 0.245 (22.07.2022) (701 supported Series):
=====================================================
Items RENAMED (11): (doaab) to (doaae), (m4addrc__e) to (m4nnww2__hx3), (m4addrc__f) to (m4nnww2__hx4), (m4addrc__n) to (m4nnww2__hx5), (sfight2) to (sfightii), (sfight2a) to (sfightiia), (sfight2b) to (sfightiib), (smb) to (smbp), (smb1) to (smbpa), (smb2) to (smbpb) and (smb3) to (smbpc).
Series NEW (1): Marble Madness.
Series UPDATED (6): Arkanoid, Cookie & Bibi, Dead or Alive, Moon Cresta, Star Force and Wonder Boy.

WhatsNew 0.244 (31.05.2022) (700 supported Series):
=====================================================
Items RENAMED (3): (hotd) to (hotdo), (j_nuddup) to (j_dud) and (j_nuddup2) to (j_duda).
Series UPDATED (7): House of the Dead, Knights of Valour, Magic Card, Moon Cresta, Neo Print, Nudge Double Up and Thunder Dragon.

WhatsNew 0.243 (06.05.2022) (700 supported Series):
=====================================================
Items RENAMED (5): (bloodstm10) to (bloodstm104), (bloodstm11) to (bloodstm110), (bloodstm21) to (bloodstm210), (bloodstm22) to (bloodstm220) and (dendego) to (dendegoa).
Series UPDATED (6): Densha de GO!, Galaxian, Photo Play, Sprint, Street Fighter and Time Killers.
Series ADDED (1): Cal Omega (38 new items).

Whatsnews 0.242 (07.04.2022) (699 supported Series):
=====================================================
Items RENAMED (9): (acedrvrw) to (acedrive), (victlapw) to (victlapa), (bmcompmx) to (bmcompmxb), (raveracj) to (raveracej), (raveracja) to (raveraceja), (raveracw) to (raverace), (ridgerac) to (ridgeracb), (ridgerac3) to (ridgeracc) and (ridgeracb) to (ridgeraca).
Series UPDATED (10): Ace Driver, Amidar, beatmania, Cruis'n USA, Dead or Alive, Frogger, Pac-Man, Pang!, Ridge Racer and Royal Card.
Series RENAMED (1): (Pang) to (Pang!)

Whatsnews 0.241 (01.03.2022) (699 supported Series):
=====================================================
Items RENAMED (2): (majest12u) to (majest12ua) and (majest12ua) to (majest12ub).
Series UPDATED (4): Crime Fighters, Heavy Barrel, Space Invaders and Teenage Mutant Ninja Turtles.

Whatsnews 0.240 (09.02.2022) (699 supported Series):
=====================================================
Items RENAMED (8): (aerofgts) to (aerofgtst), (pepk0756) to (pepk0756a), (pepk0756a) to (pepk0756b), (pepk0756b) to (pepk0756c), (pepk0756c) to (pepk0756d), (pepp0046b) to (pepp0046c), (pepp0516b) to (pepp0516c) and (pexmp017b) to (pexmp017a).
Series NEW (7): Fruit Cocktail, Garage, Gnome, Multi Fish, Resident, Rock Climber and Super Formula.
Series UPDATED (12): Aero Fighters, Crazy Monkey, Gals Panic, Island, Keks, Lucky Haunter, Pirate, Player's Edge, Rastan, Roll Fruit, Sweet Life and Tetris.

Whatsnews 0.239 (04.01.2022) (692 supported Series):
=====================================================
Items RENAMED (4): (ddpdojblka) to (ddpdojblkb), (majest12u) to (majest12ua), (srmvs) to (srmvsa) and (peps0280) to (peps0280a).
Series UPDATED (9): DonPachi, Fantasia, Final Fight, Gals Panic, Golden Tee, Off Road, Player's Edge, Puyo Puyo, Space Invaders and Super Real Mahjong.

Whatsnews 0.238 (27.11.2021) (692 supported Series):
=====================================================
Items RENAMED (1): (popn1) to (popn1a).
Series UPDATED (2): Pop'n Music, Street Fighter and Teenage Mutant Ninja Turtles.

Whatsnews 0.237 (31.10.2021) (692 supported Series):
=====================================================
Items RENAMED (3): (cosmica2) to (cosmica2a), (cosmica3) to (cosmica22) and (spcdraga) to (floritas).
Series UPDATED (6): Amidar, Cosmic, Moon Cresta, Pac-Man, Phoenix and Street Fighter.

Whatsnews 0.236 (03.10.2021) (692 supported Series):
=====================================================
Series UPDATED (3): beatmania, Head On and Mushiking - The King Of Beetle.

Whatsnews 0.235 (30.08.2021) (692* supported Series):
=====================================================
Items RENAMED (6): (gtrfrks) to (gtrfrksc), (gtrfrksa) to (gtrfrksac), (gtrfrksj) to (gtrfrksjc), (gtrfrksu) to (gtrfrksuc), (p911e) to (p911ed) and (p911uc) to (p911ac).
Series RENAMED (1): "Killing Blade" to "The Killing Blade".
Series UPDATED (7): Bubble Bobble, ESP Ra.de., Guitar Freaks, Police 24/7, Police 911, Puzzle Bobble and Time Crisis.
*: Counting done correctly.

Whatsnews 0.234 (01.08.2021) (681 supported Series):
====================================================
Items RENAMED (1): (rainwrce) to (rainwarrce).
Series UPDATED (6): Aristocrat MK Hardware, Armored Warriors, Flying Shark, Scramble, Silent Scope and Twin Bee.

Whatsnews 0.233 (06.07.2021) (681 supported series, +2):
========================================================
Items RENAMED (3): (asurabus) to (asurabusj), (asurabusa) to (asurabusjr) and (pcnfrku) to (drmnu).
Series ADDED (2): Crush Roller and Invinco.
Series UPDATED (4): Asura, Crazy Kong, Gals Panic and Percussion Freaks.

Whatsnews 0.232 (02.06.2021) (679 supported Series):
====================================================
Items RENAMED (10): (j6slagnb) to (j6snakesh), (j6slagnc) to (j6snakesi), (j6slagnd) to (j6snakesj), (j6slagne) to (j6snakesk), (j6slagnf) to (j6snakesl), (j6slagng) to (j6slagnb), (j6slagnh) to (j6slagnc), (pcnfrk3m) to (pcnfrk3mk), (pcnfrk5m) to (pcnfrk5mk) and (pcnfrk2m) to (pcnfrk2mk).
Item REMOVED (1): (nbahangtl11).
Series UPDATED (11): Alpine Racer, Dance Dance Revolution, NBA Jam, Percussion Freaks, Percussion Freaks, Pit Boss, Raiden, Snakes & Ladders, Thrill Drive, Time Killers and World Rally.

Whatsnews 0.231 (06.05.2021) (679 supported Series):
====================================================
Items RENAMED (4): (nbahangt) to (nbahangtl11), (nbajamte2) to (nbajamte2a), (outrundxeh) to (outrundxeha) and (outruneh) to (outruneha).
Series UPDATED (8): Bare Knuckle, DrumMania, JoJo's Bizarre Adventure, NBA Jam, Out Run, Percussion Freaks, Point Blank and Tekken.

Whatsnews 0.230 (05.04.2021) (679 supported series, +1):
========================================================
Items RENAMED (6): (pepp0419) to (pepp0419b), (dotron) to (dotrona), (dotrona) to (dotron), (vs299b) to (vs299j), (vs29915) to (vs29915a) and (von) to (vonu).
Series Added (2): Keyboardmania (4 items) and Pool 10 (14 items).
Series UPDATED (8): beatmania, Mega Man, Player's Edge, Shogun Warriors, Super Mario Bros., Tron, Virtua Striker and Virtual On - Cyber Troopers.

Whatsnews 0.229 (27.02.2021) (678 supported Series):
====================================================
Items RENAMED (1): (asteroidb) to (asteroidb1).
Items REMOVED (1): (blitz11).
Series UPDATED (10): Asteroids, beatmania, Defender, Drift Out, Galaxian, Pac-Man, ParaParaParadise, Player's Edge, Pop'n Music and Street Fighter.
Series RENAMED (1): (�6-X) to (L.6-X) to work around a problem caused by the "�" character.

Whatsnews 0.228 (05.02.2021) (678 supported series, -1/+2):
===========================================================
Items RENAMED (20): (bass) to (getbassur), (bassdx) to (getbassdx), (j6roller) to (j6rollerk), (j6rollera) to (j6rollerl), (j6rollerb) to (j6rollerm), (j6rollerc) to (j6rollern), (j6rollerd) to (j6roller), (j6rollere) to (j6rollera), (j6rollerf) to (j6rollerb), (j6rollerg) to (j6rollerc), (j6rollerh) to (j6rollerf), (j6rolleri) to (j6rollerg), (j6rollerj) to (j6rollerh), (j6rollerk) to (j6rolleri), (j6rollerl) to (j6rollere), (j6rollerm) to (j6rollero), (j6rollern) to (j6rollerp), (j6rollero) to (j6rollerd), (j6rollerp) to (j6rollerj) and (srally2x) to (srally2dx).
Series ADDED (2): Port Man and The Pit.
Series REMOVED (1): Bare Knuckle (MegaDrive)
Series UPDATED (27): Aristocrat MK Hardware, Astro Fighter, Bagman, beatmania, Cookie & Bibi, Crime Patrol, Darius, Dragon Ball Z, DrumMania, F-1 Grand Prix, Fatal Fury, Flying Shark, Forgotten Worlds, Get Bass - Sega Bass Fishing, Hang-On, Hat Trick Hero, Jolly Card, Jurassic Park [pinball], Moon Cresta, Pac-Man, Photo Play, Pole Position, Pool 10 [slot], Roller Coaster [slot], Scramble, Sega Rally and Street Fighter.

Whatsnews 0.227 (13.01.2021) (677 supported series, +2):
========================================================
Items RENAMED (11): (1944) to (1944u), (gdarius) to (gdariusj), (gdariusb) to (gdariusu), (f1gp) to (f1gpa), (scfinalso) to (scfinalsoc), (jupk_g51) to (jupk_501g), (croquis) to (croquisg), (finalapro) to (finalapr1), (stwr_a14) to (stwr_103_a104), (stwr_e12) to (stwr_102e) and (stwr_g11) to (stwr_101g).
Series ADDED (2): 10-Yard Fight and The Legend of Kage.
Series UPDATED (8): 19XX, Darius, F-1 Grand Prix, Hat Trick Hero, Jurassic Park [pinball], Logic Pro, Pole Position and Star Wars [pinball].

Whatsnews 0.226 (01.11.2020) (675 supported Series):
====================================================
Items REMOVED (2): (clubpacmb) and (suprmriobl3).
Items RENAMED (3): (bagmans2) to (bagmans4), (raycris) to (raycrisj) and (thrilldae) to (thrilldbe).
Series UPDATED (6): Bagman, Gunlock, Pac-Man, Space Invaders, Super Mario Bros. and Thrill Drive.

Whatsnews 0.225 (07.10.2020) (675 supported series, +3):
========================================================
Items RENAMED (7): (airduelm72) to (airdueljm72), (bagnardi) to (bagnardio), (galpani2e2) to (galpani2i2), (jojoba) to (jojobaj), (jojobar1) to (jojobajr1), (joustwr) to (jousty) and (crusnusa) to (crusnusa44).
Series ADDED (3): Bare Knuckle, Photo Play and Sunset Riders. 
Series UPDATED (16): Air Duel, Amidar, Asteroids, Astro Fighter, Bagman, Battle Garegga, Bubble Bobble, Cruis'n USA, Gals Panic, JoJo's Bizarre Adventure, Joust, Pac-Man, Road Fighter, Space Invaders, Star Horse and Street Fighter.

Whatsnews 0.224 (01.09.2020) (672 supported series, +15):
=========================================================
Items RENAMED (15): (crusnusa) to (crusnusa41), (v4cmaze2a) to (v4cmaze2_amld), (v4cmaze3a) to (v4cmaze3_amld), (v4cmazea) to (v4cmaze_amld), (dwpc) to (dwpc101j), (doa) to (doab), (drgw2c) to (drgw2100c), (drgw2hk) to (drgw2100hk), (drgw2j) to (drgw2100j), (dw2v100x) to (drgw2100x), (kov100) to (kov111), (kovshpa) to (kovshp100), (monopolya) to (monopoly4), (photoy2k102) to (photoy2k102j) and (kov100hk) to (kov114).
Items REMOVED (1): (sirio2a).
Series ADDED (16): �6-X, Bare Knuckle, Big 40 Poker, Cash Inferno, Gold Rush, Miami Dice, Monte Carlo Or Bust, Red Hot Mazooma Belle, Red Hot Poker, Reno Casino, Reno Reels, Shop Window, Sunburst, Time Bandit and Time Machine.
Series UPDATED (15): Astro Fighter, Cherry Master, Chuugokuryuu, Cruis'n USA, Crystal Maze, Dead or Alive, Dragon World, Galaxian, Knights of Valour, Monopoly, Mr. Do!, Oriental Legend, Pac-Man, Pang, Photo Y2K and Slam Masters.

Whatsnews 0.222 (14.07.2020) (657 supported series, +1):
========================================================
Items RENAMED (5): (galsnew) to (galsnewu), (galsnewa) to (galsnew), (headonb) to (foolrace), (policetr) to (policetr13) and (roadf3) to (roadfh).
Series ADDED (1): Vampire.
Series UPDATED (15): Air Duel, Cleopatra Fortune, Darkstalkers, Densha de GO!, DonPachi, Gals Panic, Head On, Pit Boss, Police Trainer, Raiden, Road Fighter, Shinobi, Street Fighter and Trivia.

Whatsnews 0.221 (21.05.2020) (656 supported series, +1):
========================================================
Items RENAMED (5): (elevator) to (elevatora), (elevator4) to (elevator), (mooncrstu) to (mooncrstuu), (xmen) to (xmenu) and (xmene) to (xmen).
Series ADDED (1): Mario Kart Arcade GP.
Series UPDATED (13): Bishi Bashi, DonPachi, Elevator Action, Final Fight, Galaxian, Metal Slug, Moon Cresta, Pang, Raiden, Space Invaders, Street Fighter, Touchmaster and X-Men.

Whatsnews 0.220 (07.04.2020) (655 supported Series):
========================================================
Series UPDATED (6): Crazy Kong, Galaxian, New Cherry '96, Pang, Scramble and Tetris.

Whatsnews 0.219 (04.03.2020) (655 supported Series):
====================================================
Items RENAMED (3): (p47aces) to (p47acesa), (tmntua) to (tmntub) and (tmntub) to (tmntuc).
Series UPDATED (18): Amidar, Battle Balls, Cabal, Club Kart, Galaxian, Moon Cresta, Mr. Do!, New Cherry '96, P-47, Pang, Puzzle & Action, Puzzli, Raiden, Star Force, Street Fighter, Teenage Mutant Ninja Turtles, Time Crisis and Time Killers.

Whatsnews 0.218 (03.02.2020) (655 supported series, +1):
========================================================
Items RENAMED (4): (sbagman) to (sbagman2), (denjinmk) to (denjinmka), (lsrquiz2) to (lsrquiz2i) and (popnstage) to (popnstex).
Series ADDED (1): Odeon Twister.
Series UPDATED (8): Bagman, Dance Dance Revolution, Denjin Makai, Laser Quiz, Mario Bros, New Cherry '96, Pop'n Stage and Quizard.

Whatsnews 0.217 (27.12.2019) (654 supported series, +1):
========================================================
Series ADDED (1): Super Mario Fushigi no Korokoro Party.
Series UPDATED (5): Cabal, MegaTouch, Raiden, Snow Bros. and Tetris.

Whatsnews 0.216 (30.11.2019) (653 supported Series):
====================================================
Items RENAMED (5): (berzerk) to (berzerka), (berzerk1) to (berzerkb), (jojo) to (jojou), (jojor1) to (jojour1) and (jojor2) to (jojour2).
Series RENAMED (1): (Cosmic Monsters) to (Cosmic).
Series UPDATED (6): Berzerk, Cosmic, Fantasy Zone, Fatal Fury, JoJo's Bizarre Adventure and Operation Wolf.

Whatsnews 0.215 (02.11.2019) (653 supported Series):
====================================================
Items RENAMED (1): (19xx) to (19xxu).
Series UPDATED (7): 194X, Bloody Roar, Derby Owners Club, Hard Head, MegaTouch, P-47 and Super Mario Bros.

Whatsnews 0.214 (29.09.2019) (653 supported Series):
====================================================
Items RENAMED (2): (psyvaria) to (psyvarij) and (powerinsp) to (powerinspu).
Series UPDATED (4): Pac-Man, Power Instinct, Psyvariar and Raiden.

Whatsnews 0.213 (08.09.2019) (653 supported Series):
====================================================
Items RENAMED (4): (hbarrel) to (hbarrelu), (hbarrelw) to (hbarrel), (swa) to (swaj) and (victor5) to (victor5a).
Series UPDATED (9): Commando, Crazy Kong, Heavy Barrel, Player's Edge, Power Instinct, Shanghai, Star Wars Arcade, Street Fighter and Victor.

Whatsnews 0.212 (07.08.2019) (653 supported series, +2):
========================================================
Series UPDATED (3): Dragon World, Teenage Mutant Ninja Turtles and Thunder & Lightning.
Series ADDED (3): F1 Exhaust Note, Lucky 21 and Video Hustler.
Series DELETED (1): Virtual On.

Whatsnews 0.211 (08.07.2019) (651 supported series, +1):
========================================================
Series UPDATED (9): Champion Poker, Gals Panic, Mushiking - The King Of Beetle, Photo Y2K, Puzz Loop, Queen Bee, Space Invaders, Taiko no Tatsujin and Thunder & Lightning.
Series ADDED (1): Virtual On - Cyber Troopers. 

Whatsnews 0.210 (09.06.2019) (650 supported Series):
====================================================
Items RENAMED (2): (pepp0550a) to (pepp0550b) and (sfex2) to (sfex2u).
Series RENAMED (3): (Dolphin Treasure) to (Dolphin Treasure * Slot), (Megatouch) to (MegaTouch) and (Paitoride) to (Last Fortress).
Series UPDATED (16): Bubble Bobble, Dolphin Treasure, Gradius, Gunlock, Jack Potten's Poker, MegaTouch, Moon Cresta, Pac-Man, Percussion Freaks, Player's Edge, Point Blank, Reelin-n-Rockin, Star Horse, Street Fighter EX, Tetris and Touchmaster.

Whatsnews 0.209 (27.04.2019) (650 supported Series):
====================================================
Series UPDATED (4): Bubble Bobble, Centipede, Empire City and Trivial Pursuit.

Whatsnews 0.208 (30.03.2019) (650 supported Series):
====================================================
Items RENAMED (2): (djboy) to (djboyu) and (djboya) to (djboyua).
Series UPDATED (4): DJ Boy, Neo Print, Raiden and Sega Rally.

Whatsnews 0.207 (01.03.2019) (650 supported series, +5):
========================================================
Items RENAMED (1): (samesamech) to (samesamecn).
Series RENAMED (2): (Pirate * Igrosoft) to (Pirate * Slot) and (Sweet Life) to (Sweet Life * Slot).
Series ADDED (4): Crazy Monkey, Hi Pai Paradise, Keks and Roll Fruit.
Series UPDATED (15): 18 Wheeler, Fire Shark, Gals Panic, Hi Sho Zame, Island, Lethal Enforcers, Neo Print, Pasha Pasha, Pirate (Igrosoft), Queen Bee, Queen of the Nile, Raiden, Sweet Life, World Class Bowling and X-Men.

Whatsnews 0.206 (03.02.2019) (645 supported series, +1):
========================================================
Items RENAMED (5): (lostwsgo) to (lostwsgp), (lupinsho) to (lupinshoo), (s1945jn) to (s1945nj), (vs4) to (vs4o) and (vs4e) to (vs4eo).
Series ADDED (1): Fire Shark.
Series UPDATED (22): Aristocrat MK Hardware, Club Kart, Denjin Makai, F-Zero, Fantasy Zone, Fire Shark, Fruit Bonus, Initial D, Jurassic Park, Key of Avalon, Lupin The Third,  Mobile Suit Gundam, Pang, Queen of the Nile, Scramble, Sega Network Taisen Mahjong, Space Invaders, Stadium Hero, Strikers 1945, Tank Battalion, Tetris Plus and Virtua Striker.

Whatsnews 0.205 (28.12.2018) (644 supported series, +2):
========================================================
Items RENAMED (4): (f1gpstar) to (f1gpstar3), (f1gpstaro) to (f1gpstar2), (sfex2p) to (sfex2pu) and (sftmj) to (sftmj112).
Series ADDED (2): Pool 10 and Super Mario Bros..
Series UPDATED (6): F1 Grand Prix Star, Player's Edge, Queen of the Nile, Street Fighter, Street Fighter EX and Trivial Pursuit.

Whatsnews 0.204 (29.11.2018) (642 supported Series):
====================================================
Items RENAMED (6): (pbaction2) to (pbactiont), (pbaction3) to (pbaction2), (pbaction4) to (pbaction3), (pbaction5) to (pbaction4), (shinobi5) to (shinobi6) and (xmcotaar1) to (xmcotaar2).
Series UPDATED (13): Centipede, Fighting Vipers, Jurassic Park, Pinball Action, Sega Rally, Shinobi, Snow Bros., Star Wars Arcade, Street Fighter, Touchmaster, Virtual On, X-Men and Xevious.

Whatsnews 0.203 (02.11.2018) (642 supported Series):
====================================================
Items RENAMED (1): (armchmp2) to (armchmp2o2).
Series UPDATED (9): Ace Driver, Arm Champs, Pac-Man, Pang, Phoenix, Player's Edge, Pocket Gal, Street Fighter and Tetris.

Whatsnews 0.202 (28.09.2018) (642 supported series, +5):
========================================================
Items RENAMED (5): (cybsledj) to (cybsleda), (galpani4) to (galpani4j), (wecleman) to (weclemana), (weclemana) to (weclemanb) and (weclemanb) to (weclemanc).
Serie RENAMED (1): (Racin' Force) to (WEC Le Mans).
Series UPDATED (8): Asteroids, Crime Fighters, Frogger, Gals Panic, Hard Head, House of the Dead, Pac-Man and Road Fighter.
Series ADDED (5): Amidar, Lucky Balls Casino Slot, Lucky Haunter Slot, Lucky Las Vegas Slot and Midnight Landing. 

Whatsnews 0.201 (31.08.2018) (637 supported series, -5):
========================================================
Items RENAMED (2): (sshangha) to (sshanghaj) and (wwfwfestb) to (wwfwfestub).
Items and Series REMOVED (39): Various game duplicated removed.
Series UPDATED (12): 18 Wheeler, Club Kart, Golfing Greats, House of the Dead, Ikari, King of Fighters, Mario Bros., Raiden, Shanghai, Tecmo World Cup, Virtua Striker and WWF Superstars.
Series ADDED (1): F-Zero.

Whatsnews 0.200 (27.07.2018) (642 supported series, +1):
========================================================
Series UPDATED (7): Donkey Kong, Hayaoshi Quiz, Ibara, Mario Bros., Raiden, Scramble and Street Fighter.
Serie ADDED (1): Battle Balls.

Whatsnews 0.199 (30.06.2018) (641 supported Series):
====================================================
Items RENAMED (2): (gtg) to (gtgj31) and (puyofev) to (puyofevj).
Series UPDATED (2): Golden Tee and Puyo Puyo.

Whatsnews 0.198 (01.06.2018) (641 supported series, +3):
========================================================
Series ADDED (3): Jikkyou Powerful Pro Yakyuu, Marvel Super Heroes and V-Liner.
Series UPDATED (11): Centipede, Donkey Kong, Final Fight, King of Fighters, Marvel Vs. Capcom, Sonic Blast Man, Sengoku, Spy Hunter, Street Fighter, Strider and World Heroes.

Whatsnews 0.197 (27.04.2018) (638 supported series, +4):
========================================================
Item RENAMED (1): (wrally2) to (wrally2a).
Series ADDED (4): Amazonia King, Cross Pang, Jolly Card and WWF Wrestlemania.
Series UPDATED (5): Fatal Fury, Popeye, Street Fighter, Time Killers and World Rally.

Whatsnews 0.196 (01.04.2018) (634 supported Series):
====================================================
Series UPDATED (4): Big Buck Hunter, Daytona USA, Fantasy Zone and Street Fighter.

Whatsnews 0.195 (01.03.2018) (634 supported series, +1):
========================================================
Series ADDED (1): Tecmo Bowl.
Series UPDATED (7): Donkey Kong, Gee Bee, Gigas, Pac-Man, Player's Edge, Quarterback and Street Fighter.

Whatsnews 0.194 (03.02.2018) (633 supported series, -11):
=========================================================
Items RENAMED (12): (47pie2) to (suchie2), (47pie2o) to (suchie2o), (ddpdojh) to (ddpdojt), (gnw_dj101) to (gnw_dkjr), (gnw_jr55) to (gnw_dkong2), (gnw_mw56) to (gnw_mario), (kov2nl) to (kov2nl_302cn), (kov2nl_300) to (kov2nl_300cn), (kov2nl_301) to (kov2nl_301cn), (sstrikera) to (sstrikerk), (suchipi) to (suchiesp) and (weststory) to (weststry).
Series UPDATED (2): 777 Heaven and Bar 7's.

Whatsnews 0.193 (28.12.2017) (644 supported Series):
====================================================
Items RENAMED (9): (bloodbro) to (bloodbroja), (bloodbroa) to (bloodbroj), (bloodbrob) to (bloodbro), (mario) to (mariof), (marioo) to (mario), (orleg2) to (orleg2_104cn), (orleg2_101) to (orleg2_101cn), (orleg2_103) to (orleg2_103cn) and (weststry) to (weststory).

Whatsnews 0.192 (29.11.2017) (644 supported series, +1):
========================================================
Items RENAMED (6): (champbb2a) to (tbasebal), (kov2nlo) to (kov2nl_301), (kov2nloa) to (kov2nl_300), (mtkob2) to (mushike), (orleg2o) to (orleg2_103) and (orleg2oa) to (orleg2_101).
Series UPDATED (1): SD Gundam.
Series ADDED (1): Cyberball.

Whatsnews 0.191 (25.10.2017) (643 supported Series):
====================================================
Items RENAMED (4): (cstrip) to (cs1_spp2), (cstripix) to (cs9_spp),  (cstripviii) to (cs8_spp) and  (cstripxi) to (cs11_sps).
Series UPDATED (10): After Burner, Athena, Cabal, Casino Strip, Eight Ball (Pinball), Hang-On, Knights of Valour, Thunder Hoop, Tecmo World Cup and World Series.
Series ADDED (1): E-Touch Mahjong.

Whatsnews 0.190 (29.09.2017) (643 supported series, +1):
========================================================
Items RENAMED (12): (bbhsc) to (bbhsca), (mp_twc) to (mp_twcup), (tecmowcm) to (twcupmil), (twrldc94) to (twcup94), (twrldc94a) to (twcup94a), (tws96) to (twsoc96), (wc90) to (twcup90), (wc90a) to (twcup90a), (wc90b) to (twcup90b), (wc90b1) to (twcup90b1), (wc90b2) to (twcup90b2) and (wc90t) to (twcup90t).
Series UPDATED (3): Big Buck Hunter, Beast Busters and Shootout Pool.

Whatsnews 0.189 (03.09.2017) (642 supported series, +4):
========================================================
Items RENAMED (13): (1943ja) to (1943jah), (brapboysj) to (brapboyspj), (brapboysu) to (brapboyspu), (cawingu) to (cawingur1), (inttootea) to (inttoote2), (podrace) to (swracer), (shocktro) to (shocktroa), (shocktroa) to (shocktro), (vendetta2p) to (vendetta2pw), (vendettaj) to (vendetta2pp), (vf4evo) to (vf4evob), (wwfsstaru) to (wwfsstaru7) and (wwfsstarua) to (wwfsstaru4).
Series UPDATED (15): 194X, Chase H.Q., Crazy Climber, Crime Fighters, Derby Owners Club, DJ Boy, DonPachi, Donkey Kong, Popeye, Print Club, Street Fighter, Tekken, U.N. Squadron, Virtua Fighter and WWF Superstars.
Series ADDED (1): Sexy Gal.

Whatsnews 0.188 (29.07.2017) (638 supported Series):
====================================================
Items RENAMED (4): (kinst2k3) to (kinst2uk), (retofinv1) to (retofinvb1), (retofinv2) to (retofinvb2) and (xevi3dg) to (xevi3dgj).
Items REMOVED (7): (kinst13), (kinst14), (kinst210), (kinst211), (kinst213), (kinst2k4) and (kinstp).
Series UPDATED (21): Bubble Bobble, Burger Time, Crazy Climber, Crazy Kong, Darwin, Dig Dug, Donkey Kong, Fighting Vipers, Frogger, Galaxian, Gauntlet, Mario Bros., Operation Wolf, Pac-Man, Q*Bert, Scramble, Space Invaders, Street Fighter, Virtua Striker, Xevious and Zaxxon.
Series ADDED (4): Casino Strip, Need for Speed, Percussion Freaks and Triv Quiz.

Whatsnews 0.187 (30.06.2017) (638 supported Series):
====================================================
Series UPDATED (7): E-Swat Cyber Police, Out Run, Player's Edge, Power Instinct, Rally X, Scramble and Super Spacefortress Macross.

Whatsnews 0.186 (04.06.2017) (638 supported series, +2):
========================================================
Items RENAMED (23): (cvs2gd) to (cvs2mf), (jclub2) to (jclub2v200), (jclub2o) to (jclub2v112), (jclub2ob) to (jclub2v203), (jgakuen) to (jgakuen1), (megaforc) to (megaforcu), (qnilese) to (qnilesea), (rastsaga) to (rastsagaa), (rastsagaa) to (rastsagab), (souledgeaa) to (souledgea), (specfrce) to (specfrceo), (tekken) to (tekkenac), (tekken2aa) to (tekken2a), to (tekken2ab) to (tekken2b), (tekken3) to (tekken3je1), (tekken3aa), to (tekken3a), (tekken3ab) to (tekken3b), (tekken3ae) to (tekken3), (tekkenab) to (tekkenb), (tekkenac) to (tekken), (tektagt) to (tektagtuc1), (tektagtac) to (tektagt) and (tektagtac1) to (tektagtc1).
Series UPDATED (13): Bagman, Dragon Treasure, Jockey Club, Megatouch, Pac-Man, Pang, Player's Edge, Queen of the Nile, Rastan, SNK vs. Capcom, Star Force, Tekken and Touchmaster. 

Whatsnews 0.185 (30.04.2017) (636 supported series, +1):
========================================================
Items RENAMED (1): (machbrkr) to (machbrkrj).
Series UPDATED (7): Gals Panic, Knights of Valour, MegaTouch, Police Trainer, Prehistoric Isle, Rastan and Street Fighter.
Series ADDED (2): Galaxy Games and Sonic Blast Man.

Whatsnews 0.184 (29.03.2017) (635 supported Series):
====================================================
Items RENAMED (6): (chariotc) to (chariotcv), (dolphntrce) to (dolphntrcea), (magimask) to (magimaskb), (minemine) to (minemineu), (raiden2g) to (raiden2eg) and (suprgolf) to (suprgolfj).
Series UPDATED (7): Dolphin Treasure, Gals Panic, Phoenix, Raiden, San Francisco Rush, Shanghai and Street Fighter.
Series ADDED (1): Queen of the Nile.

Whatsnews 0.183 (26.02.2017) (635 supported Series):
====================================================
Items RENAMED (7): (galpans2) to (galpans2j), (kof99k) to (kof99ka), (pitboss) to (pitboss04), (pitbossa) to (pitboss03), (pitbossa1) to (pitboss03a), (pitbossb) to (pitbossps) and (pitbossc) to (pitbossm4).
Series UPDATED (8): Defender, Dolphin Treasure, Dungeons & Dragons, Gals Panic, King of Fighters, Pit Boss, Star Horse and Virtual On.

Whatsnews 0.182 (25.01.2017) (635 supported Series):
====================================================
Items RENAMED (5): (starhrcl) to (shorse), (starhrct) to (shorsel), (starhrpr) to (shorsepr), (starhrse) to (shorsem) and (starhrsp) to (shorsep).
Series UPDATED (5): Astro Fighter, Eight Ball, King of the Monsters, Samurai Shodown and Star Horse.

Whatsnews 0.181 (28.12.2016) (635 supported Series):
====================================================
Items RENAMED (1): (sidebs2j) to (sidebs2ja).
Series UPDATED (8): Fatal Fury, Fire Shark, Knights of Valour, Miss World, Player's Edge, Raiden, Side By Side and Virtua Striker.

Whatsnews 0.180 (30.11.2016) (635 supported Series):
====================================================
Items RENAMED (15): (f1gpstar) to (f1gpstaro), (forgottnu1) to (forgottnuc), (pepp0008) to (pepp0008b), (pepp0048) to (pepp0048b), (pepp0055) to (pepp0055b), (pepp0055a) to (pepp0055), to (pepp0055b) to (pepp0055a), (pepp0057a) to (pepp0057d), (pepp0103) to (pepp0103b), (pepp0126) to (pepp0126a), (pepp0127a) to (pepp0127b), (pepp0452) to (pepp0452a), (srallyca) to (srallycdx), (wwfwfest) to (wwfwfestu) and (wwfwfesta) to (wwfwfest).
Series UPDATED (9): Crime Fighters, F1 Grand Prix Star, Forgotten Worlds, Metal Slug, Pole Position, Road Fighter, Sega Rally, Space Invaders and Time Crisis.

Whatsnews 0.179 (26.10.2016):
=============================
Items RENAMED (1): (doa2) to (doa2a).
Series ADDED (2): Splendor Blast and Wing War.
Series UPDATED (5): BombJack, Dead or Alive, Player's Edge, Triv and Teenage Mutant Ninja Turtles.

Whatsnews 0.178 (28.09.2016):
=============================
Items RENAMED (4): (mightybj) to (nvs_mightybj), (roadriot) to (roadriota), (roadrioto) to (roadriotb) and (vf3) to (vf3c).
Series ADDED (1): Pop'n Stage.
Series UPDATED (12): Elevator Action, NBA Jam, Pac-Man, Phoenix, Popeye, Qix, Raiden, Road Riot, Sega Skateboarding, Street Fighter, Tecmo World Cup and Virtua Fighter.

Whatsnews 0.177 (31.08.2016):
=============================
Items RENAMED (8): (m4addrcc) to (m4addrcc__c), (m4addrcc__c) to (m4addrcc), (m4andybt) to (m4andybt__b), (m4andybt__b) to (m4andybt), (ssf2xj) to (ssf2xjr1), (ssf2xjd) to (ssf2xjr1d), (ssf2xjr) to (ssf2xjr1r) and (vcop3) to (vcop3a).
Series ADDED (1): Zero Team.
Series UPDATED (7): Key of Avalon, Mobile Suit Gundam, Out Run, Street Fighter, Teenage Mutant Ninja Turtles, Virtua Cop and Wangan Midnight.

Whatsnews 0.176 (27.07.2016):
=============================
Items RENAMED (3): (bubbletr) to (bubbletrj) and (enchfrst) to (eforsta5) and (othunder) to othundero).
Items WRONG REMOVED (7): (dangar2), (geishanz), (goldprmd), (indiandr), (qotn), (swthrt2v) and (swtht2nz).
Series UPDATED: Cosmic Monsters, Golly! Ghost! and Operation Wolf.
PS: A lot of deleted items (about 150) because duplicate. 

Whatsnews 0.175 (29.06.2016):
=============================
Items RENAMED (41): (50lionsa) to (50lionsm), (adonise) to (adonisu),  (antcleo) to (antcleom),  (bootsctn) to (bootsctnu),  (bumblbug) to (bumblbugu),  (cashcham) to (cashchamu),  (choysun) to (csdm),  (crystals) to (crysprim),  (cuckoo) to (cuckoou),  (dmdtouch) to (dimtouch), (dolphtra) to (dolphntra), (dolphtre) to (dolphntru),  (enchfrst) to (eforsta5),  (geishanz) to (geisha),  (goldprmd) to (goldpyr),  (indiandr) to (indrema5),  (indianmm) to (indremmm),  (magicmsk) to (magimask),  (magicmska) to (magimaska),  (margmgc) to (marmagic),  (pengpays) to (pengpayu),  (qotn) to (qnileb),  (qotna) to (qnileu), (swthrt2v) to (swhr2v),  (thaiprin) to (thaiprncm),  (wheregld) to (wheregldm),  (wildways) to (wwaysm) and  (wldcougr) to (wcougaru).
Series ADDED: Flaming 7 and Queen of the Nile.
Series UPDATED: 194X, Bishi Bashi, Buena Suerte, Galaxian, Marvel Vs. Capcom, Moon Cresta, Out Zone, Royal Card, Scramble, Side by Side, Space Invaders, Street Fighter, Teenage Mutant Ninja Turtles and World Club Champion Football.

Whatsnews 0.174 (25.05.2016):
=============================
Items RENAMED: (hotd4) to (hotd4a), (hsf2j) to (hsf2j1), (xmvsfj) to (xmvsfjr1),  (xmvsfjr1) to (xmvsfjr2) and  (xmvsfjr2) to (xmvsfjr3).
Series UPDATED: Champion Poker, Commando, Empire City, House of the Dead, Lucky 8 Lines, Marvel Vs. Capcom and Shogun Warriors.

Whatsnews 0.173 (27.04.2016):
=============================
Items RENAMED: (dsaber) to (dsabera), (majest12) to (majest12j) and (wangmd2b) to (wangmid2).
Items REMOVED: (tv1943), (tvaburn), (tvbomber), (tvdrgnst), (tvopwolf), (tvpaclnd), (tvpdrift), (tvraiden), (tvrs2), (tvrtype2), (tvshnobi), (tvslmndr), (tvsson2), (tvtcrst2) and (tvxvious).
Series UPDATED: Beast Busters, DonPachi, ESP Ra.De., Galaxian, Ketsui: Kizuna Jigoku Tachi, Major Title, Mortal Kombat, Operation Wolf, Print Club, Raiden, Space Invaders and Wonder Boy.

Whatsnews 0.172 (30.03.2016):
=============================
Items RENAMED: (crimfght) to (crimfghtu), (crimfght2) to (crimfght), (pepk0756b) to (pepk0756c), (pepk0756a) to (pepk0756b), (pepk0756) to (pepk0756a) and (sbishik) to (sbishika).
Series ADDED: Super Poker.
Series UPDATED: Big Buck Hunter, Bishi Bashi, Cabal, Cherry Master, Crazy Climber, Major Title, Moon Cresta, Pac-Man, Player's Edge, Phoenix, Robotron, Track & Field, Wave Runner and Wonder Boy.

Whatsnews 0.171 (28.02.2016):
=============================
Items RENAMED: (mj2) to (mj2f), (mj2g) to (mj2), (pclb297w) to (prc297wi), (pclb298a) to (prc298au), (pclub298) to (prc298sp) and (wrallyb) to (wrallyat).
Entries FIXED: Police 911.
Series ADDED: Dragon Treasure and Frogger.
Series UPDATED: 194X, Asteroids, Bubble Bobble, Great 1000 Miles Rally, Jurassic Park, Multi Champ, NBA Jam, Police 24/7, Print Club, Raiden, Silent Scope, Thrill Drive, Wangan Midnight, World Combat and World Rally.

Whatsnews 0.170 (27.01.2016):
=============================
Items RENAMED: (basschal) to (basschalo).
Series ADDED: Power Drift and Sega Bass Fishing.
Series UPDATED: 194X, After Burner, Bomber Man, Dragon Spirit, Gradius, Gun Dealer, Multi Game, Nova 2001, Operation Wolf, Moon Cresta, Pac-Man, Raiden, R-Type, Shinobi, Son Son, Stadium Hero and Xevious.

Whatsnews 0.169 (02.01.2016):
=============================
Items RENAMED: (glassbrk) to (glass10a), (peke1012a) to (peke1012b), (peke1012) to (peke1012a), (pepp0060b) to (pepp0060c), (pepp0290) to (pepp0290a), (pepp0190b) to (pepp0190c), (pepp0190a) to (pepp0190b), (pepp0265b) to (pepp0265c), (pex0002pa) to (pex0055pq) and (rungunu) to (rungunud).
Items REMOVED: (pex0055pq) and (mk6nsw11).
Series ADDED: Kick and Run, Muscle Bomber, Slam Dunk, Triple Punch, World Club Champion Football and Xexex.
Series UPDATED: Double Dragon, Dragon World, Gallop Hard Head, Hat Trick Hero, Lethal Enforcers, Miss World, Mortal Kombat, Ninja-Kid, Player's Edge, Splash!, Run and Gun and Street Fighter.

Whatsnews 0.168 (27.11.2015):
=============================
Items RENAMED: (ffreveng) to (ffrevng10), (fghthist) to (fghthista), (fghthista) to (fghthistb), (pepp0203b) to (pepp0203c), (pepp0203c) to (pepp0203d) and (pepp0203d) to (pepp0203e).
Items REMOVED: (grfore02o), (mp_gaxe), (poleposa), (pps63), (scrambt) and (sidebs2ja).
Entries FIXED: (4ndup) to (m4ndup), (area5mx) to (area51mx), (bagnardyi) to (bagnardi), (dduxb1) to (ddux1), (grfore04) to (gtfore04), (m4dash) to (m4bdash), (olds100t) to (olds103t), (othdrby) to (othldrby), (shikgam3) to (shikiga3) and (xmvsj) to (xmvsfj).
Series ADDED: Forgotten Worlds, Jack Potten's Poker, Karate Blazers and Witch Jack.
Series UPDATED: 194X, Cherry Master, Club Kart, Dynamite Dux, Fighter's History, Final Fight, Galaxian, Initial D, Nudge Double Up Slot, Out Run, Player's Edge, Rolling Thunder, Sengoku Ace, Scramble, Star Wars and Tank.

Whatsnews 0.167 (31.10.2015):
=============================
Items RENAMED: (ffightub) to (ffightuc), (peke1013) to (peke1013a), (pepp0042) to (pepp0042a), (pepp0055b) to (pepp0055c), (pepp0515) to (pepp0515a), (pepp0515a) to (pepp0515b), (pepp0515b) to (pepp0515c) and (wecleman2) to (weclemana).
Series ADDED: Air Duel, Aristocrat MK Hardware, SDI - Strategic Defense Initiative.
Series UPDATED: beatmania, Bubble Bobble, DonPachi, Donkey Kong, Final Fight, Joe & Mac, Ketsui: Kizuna Jigoku Tachi, Led Storm, Neo Print, Out Run, Player's Edge, R-Type, Racin' Force.

Whatsnews 0.166 (30.09.2015):
=============================
Items RENAMED: (clubkrte) to (clubkrto), (clubkrtd) to (clubkrt), (hyprolymb) to (hyprolymba), (mbaa) to (mbaao), (mbaaa) to (mbaa), (meltyb)n to (meltybo), (meltyba) to (meltyb), (mushik2e) to (mushi2eo), (mushi2ea) to (mushik2e), (radirgy) to (radirgyo), (radirgya) to (radirgy), (ss2005) to (ss2005o), (ss2005a) to (ss2005), (vf4) to (vf4o), (vf4c) to (vf4), (vstrik3c) to (vstrik3co) and (vstrik3cb) to (vstrik3c).
Series ADDED: Amazonia King. 
Series UPDATED: Major League, Melty Blood, Golden Axe, Hang-On, Hard Head, Monaco GP, Oriental Legend, Out Run, Pac-Man, Point Blank, Ridge Racer, Rolling Thunder, Shinobi, Soul Edge, Tekken, Tetris, Track & Field, Wonder Boy.

Whatsnews 0.165 (28.08.2015):
=============================
Items RENAMED: (fghthistub) to (fghthistuc), (fghthistua) to (fghthistub), (fghthistu) to (fghthistua), (gtsers8) to (gtsers8a) and (peke1012) to (peke1012a).
Items REMOVED: (gtsers10a).
Series ADDED: Knuckle Bash, Mahjong The Mysterious World.
Series UPDATED: Dragon's Lair, Fighter's History, Trivia, Player's Edge, Street Fighter.

Whatsnews 0.164 (29.07.2015):
=============================
Items RENAMED: (bublbob2) to (bublbob2o), (ghunter) to (ghunters), (mj2) to (2j2g), (mj2f) to (mj2), (quizard) to (quizard3_32), (quizrd12) to (quizard_12), 
(quizrd17) to (quizard_17), (quizrd18) to (quizard), (quizrd22) to (quizard2_22), (quizrd23) to (quizard2), (quizrd34) to (quizard3), (quizrr40) to (quizard4_40), (quizrr41) to (quizard4_41) and (quizrr42) to (quizard4).
Series ADDED: Galaxy Force.
Series UPDATED: Bubble Bobble, Crime Fighters, Final Fight, Empire City, Heavy Barrel, Mortal Kombat, NBA Jam, NFL Blitz, Quizard, Run and Gun, Scramble, The Rumble Fish, X-Men.

Whatsnews 0.163 (24.06.2015):
=============================
Items RENAMED: (bbustersu) to (bbustersua), (gloc) to (glocu), (pepp0040a) to (pepp0040b), (pepp0197a) to (pepp0197b), (pepp0197b) to (pepp0197c), (pepp0250) to (pepp0250a), (pepp0410) to (pepp0410a), (pepp0423) to (pepp0423b), (vigilano) to (vigilanto) and (vigilanbl  ) to (vigilantbl).
Series ADDED: Dunk Shot, New Cherry '96.
Series UPDATED: After Burner, Beast Busters, Fantasia, Gradius, Paradise, Player's Edge, Twin Bee.

Whatsnews 0.162 (27.05.2015):
=============================
Items RENAMED: (gtfore02) to (gtfore03), (gtfore05) to (gtfore05b), (pexmp030) to (pexmp030a), (vigilant1) to (vigilantc), (vigilantj) to (vigilantd), (vigilantu) to (vigilano) and (vigilantu2) to (vigilantg).
Series ADDED: Big Buck Hunter.
Series UPDATED: Contra, Golden Tee, Kung-Fu Master, Player's Edge.

Whatsnews 0.161 (29.04.2015):
=============================
Items RENAMED: (area51t) to (area51ta), (fghthistua) to (fghthistub), (fghthistu) to (fghthistua), (pepp0542) to (pepp0542a), (rdftj) to (rdftja), (rdft) to (rdftj), (rdft2a2) to (rdft2aa), (rdft2j2) to (rdft2ja) and (robocop2u) to (robocop2ua).
Series ADDED: Chuugokuryuu, Dinosaur King, Zoids.
Series UPDATED: Area 51, Berzerk, Breakout, Champion Baseball, DonPachi, Double Dragon, Fighter's History, Player's Edge, Raiden, RoboCop, Taiko no Tatsujin.

Whatsnews 0.160 (27.03.2015):
=============================
Items RENAMED: (pepp0190a) to (pepp0190b), (pepp0190) to (pepp0190a), (pepp0158c) to (pepp0158d), (pepp0158b) to (pepp0158c), (pepp0515) to (pepp0515a) and (pepp0515a) to (pepp0515b).
Series UPDATED: Capcom World, Golden Axe, Player's Edge, Raiden.

Whatsnews 0.159 (27.02.2015):
=============================
Items RENAMED: (avalon13) to (avalnc13), (avalons) to (avalonsc), (eca) to (ecau) and (ecax) to (eca).
Series ADDED: Ghost Squad, Sega Network Taisen Mahjong, Section Z.
Series  UPDATED: Asura, Key of Avalon, Super Spacefortress Macross, Player's Edge, Virtua Striker.

Whatsnews 0.158 (02.02.2015):
=============================
Series ADDED: Shakatto Tambourine.
Series  UPDATED: Capcom World, Dungeons & Dragons, Player's Edge, Pop'n Music.

Whatsnews 0.157 (01.01.2015):
=============================
Series ADDED: Space Duel, Virtua Tennis.
Series  UPDATED: After Burner, Breakout, Fantasy Zone, Guilty Gear, House of the Dead, Initial D, Melty Blood, Mortal Kombat, Out Run, Player's Edge, Ridge Racer, Star Horse, Street Fighter, Tekken, Time Crisis, Virtua Fighter.

Whatsnews 0.156 (30.11.2014):
=============================
Items RENAMED: (clubk2kf) to (clubk2kp), (futaribl) to (futariblj), (pbst30b) to (pbst30a) and (sf2mdtc) to (sf2b).
Series ADDED: Rad Action.
Series  UPDATED: After Burner, Arkanoid, Battle Garegga, Breakout, Club Kart, Darius, Donkey Kong, Dragon World, Knights of Valour, Kung-Fu Master, Oriental Legend, Megatouch, Phoenix, Player's Edge, Play Girls, Pop'n Music, Raiden, Space Invaders, Teenage Mutant Ninja Turtles, Tetris, Tron.

Whatsnews 0.155 (17.10.2014):
=============================
Items RENAMED: (19xxa) to (19xxar1), (arkanoidj) to (arkanoidja), (arkanoidjb) to (arkanoidjbl), (arkanoidjb2) to (arkanoidjbl2), (arkanoidjo) to (arkanoidjb), (armwara) to (armwarar1), (centiped) to (centiped3), (centtime) to (centiped), (crimep211) to (crimep2_11), (crimepat) to (crimepat_14), (maddog21) to (maddog2_100), (maddog22) to (maddog2_202), (pepp0158b) to (pepp0158c), (pepp0158a) to (pepp0158b), (pepp0158) to (pepp0158a), (punchout) to (punchouta), (raiden2a) to (raiden2hk), (raiden2b) to (raiden2j), (raiden2c) to (raiden2i), (raiden2e) to (raiden2ea), (raiden2d) to (raiden2e), (raiden2f) to (raiden2eu), (raiden2g) to (raiden2eua), (sboblboa) to (sboblbobla), (sboblbob) to (sboblboblb), (searchey) to (searcheya), (sf) to (sfan), (sfu) to (sf) and (ssf2) to (ssf2r1).
Series  UPDATED: 194X, Arkanoid, Armored Warriors, Centipede, Crime Fighters, Crime Patrol, Donkey Kong, Dragon's Lair, Galaxian, Initial D, Mad Dog, Mario Bros., Mega Man, Pac-Man, Player's Edge, Phoenix, Punch-Out!!, Raiden, Street Fighter, Wonder Boy.

Whatsnews 0.154 ( 27.07.2014):
==============================
Items RENAMED: (initdexp) to (initdexpo), (pepp0060   > pepp0060a), (pepp0060a) to (pepp0060), (pepp0197) to (pepp0197b), (pepp0197a) to (pepp0197), (pepp0417) to (pepp0417a), (pepp0417a) to (pepp0417), (pepp0203) to (pepp0203b), (pepp0203a) to (pepp0203), (pepp0203b) to (pepp0203a), (pepp0265) to (pepp0265a), (pepp0265a) to (pepp0265), (pepp0516) to (pepp0516a), (pepp0516a) to (pepp0516) and (raidendxj) to (raidendxk).
Series  UPDATED: 1942, Cherry Master, Galaxian, High Speed Pinball, Initial D, Joust, Knights of Valour, Pac-Man, Phoenix, Player's Edge, Space Invaders, Tetris.

Whatsnews 0.153 (12.04.2014):
=============================
Items RENAMED: (19xxjr1) to (19xxjr2), (19xxj) to (19xxjr1), (dspirita) to (dspirit2), (dspirito) to (dspirit1), (mrdrillr) to (mrdrillrj), (pepp0235) to (pepp0265a), (sfiiin) to (sfiiina), (shangha3) to (shangha3u), (shanghai) to (shanghaij) and (stoffy) to (stoffyu).
Series ADDED: Club Kart, Deathsmiles, Mushihime-Sama, Ibara, Indy Atari, Miss World, Royal Card, Star Horse. 
Series  UPDATED: 18 Wheeler, 194X, Chase H.Q., Cookie & Bibi, Street Fighter, DonPachi, Donkey Kong, Bar 7's Slot, Fantasia, Fighter's History, Galaxian, Gals Panic, Intrepid, Jockey Club, King of Fighters, Lethal Enforcers, Centipede, Monaco GP, Mr. Driller, Pac-Man, Mushiking - The King Of Beetle, Out Run, Player's Edge, Ibara, Puyo Puyo, Radirgy, Raiden, Street Fighter, Shanghai, Snow Bros., Tekken.

Whatsnews 0.152 (29.12.2013):
=============================
Items RENAMED: (bmiidx) to (bmiidxa), (bmiidx3) to (bmiidx3a), (bmiidx6) to (bmiidx6a), (dstage) to (dstagea), (glpracr) to (glpracrj), (pexmp002) to (pexm004p), (pexmp003) to (pexm001p), (pexmp004) to (pexm005p), (pexmp006a) to (pexm002p), (pexs0006) to (pex0998s) and (sfiii) to (sfiiiu).
Entries DELETED: (pexmp003a), (pexmp003b), (pexmp006), (pexmp006b) and (pexmp024).
Series  UPDATED: 194X, beatmania, Commando, Donkey Kong, Dancing Stage, Gallop Racer, Player's Edge, Scramble, Street Fighter, Touchmaster and Touchmaster.

Whatsnews 0.151 (10.11.2013):
=============================
Items RENAMED: (bbmanwj) to (bbmanwja), (pexmp006) to (pexmp006a), (pexp0019) to (pex2025p), (pexp0112) to (pex2035p), (sisv) to (sisv3), (sitvo) to (sitv1), (sisv2) to (sisv), (strkfgtr) to (strkfgtrj), (xmvsfar2) to (xmvsfar3) and (xmvsfar1) to (xmvsfar2).
Series ADDED: Dynamite Dux, E-Swat Cyber Police, Emergency Call Ambulance, Fire Shark and X-Men.
Series UPDATED: After Burner, Bomber Man, Burger Time, Final Fight, Marvel Vs. Capcom, Player's Edge, Space Invaders and Street Fighter.

Whatsnews 0.150 (20.09.2013):
=============================
Series ADDED: 10 x 10 Slot, 777 Heaven Slot, A Nightmare On Elm Street Slot, Ace Chase Slot, Ace Of Clubs Slot, Action 2000 Slot, Action Bank Slot, Addams Family Slot, Adders & Ladders Slot, Aladdin's Cave Slot, American Beauty Slot, Andy Capp Slot, Ant & Dec's Jiggy Bank Slot, Around The Board, In 40 Days Slot, Bar 7's Slot, Bar X Slot, Bedazzled Slot, Big Ben Slot, Bingo Belle Slot, Boulder Dash Slot, Break The Bank Slot, Bullseye Slot, Camelot Slot, Cannonball Run Slot, Caribbean Cash Slot, Cash Adder Slot, Cash Explosion Slot, Cash Lines Slot, Cash Raker Slot, Casino Beaver Las Vegas Slot, Casino Crazy Slot, Casino Crazy Fruits Slot, Casino Crazy Keys Slot, Casino Royale Slot, Cluedo Slot, Colour Of Money Slot, Cops 'n' Robbers Slot, Coronation Street Slot, Cracker Slot, Crown Jewels Slot, Deal Or No Deal Slot, Del's Millions Slot, Deluxe Monopoly Slot, Donkey Kong Slot, Down Town Slot, Dr.Who The Timelord Slot, Dungeons & Drag Queens Slot, Eastenders - Queen Vic Slot, Easy Money Slot, Family Guy Slot, Fight Night Slot, Filthy Rich Slot, Firecracker Slot, Full Moon Fever Slot, Gold Digger Slot, Golden Nugget Slot, Hi De Hi Slot, Hi Flyer Slot, Hot Dogs Slot, Hot Pots Slot, Hot Shot Slot, Italian Job Slot, Jokers Gold Slot, Make A Million Slot, Manic Miner Slot, Match Of The Day Slot, Nudge Double Up Slot, Nuns 'n' Roses Slot, Open The Box Slot, Pharaoh's Gold Slot, Pinball Wizard Slot, Pink Panther Slot, Play It Again Slot, Popeye, Popeye Slot, Pot Of Gold Slot, Pound For Pound Slot, Premier Club Slot, Roller Coaster Slot, Sengoku Ace,  Snakes & Ladders Slot, Sonic Wings, Spotted Dick Slot, Temple Of Treasure Slot, The Addams Family Pinball, The Great Escape Slot, The Simpsons Slot, Thunderbirds Slot, Tomb Raider Slot, Trivial Pursuit Slot, Twilight Zone Slot, Viva Rock Vegas Slot, Wild West Slot, Win Can Alley Slot, Winning Run, Zig Zag Slot.
Series UPDATED: 194X, All Japan Pro Wrestling, Alpha Mission, Area 51, Arkanoid, Asteroids, Bagman, Battle Garegga, Battle Gear, beatmania, Bishi Bashi, Bloody Roar, Bomb Jack, Bubble Bobble, Boulder Dash, Centipede, Champion Poker, Chase H.Q., Cherry Master, Columns, Commando, Contra, Crackin' DJ, Crazy Climber, Crime Fighters, Crown Golf, Cruis'n USA, Crystal Maze, Dancing Stage, Darkstalkers, Daytona USA, DJ Boy, Donkey Kong, DonPachi, Double Dragon, Dragon Ball Z, Dragon's Lair, Drift Out, Dynamite Baseball, Dynasty Wars, Elvira Pinball, Empire City, ESP Ra.De., Exciting Soccer, Fantasia, Fantasy Zone, Fatal Fury, Fighter's History, Final Fight, Final Furlong, Flying Shark, Fruit Bonus, Fun Cube, Galaxian, Gals Panic, Gauntlet, Get Bass, Ghosts'n Goblins, Giga Wing, Golden Axe, Golden Tee, Gradius, Green Beret, GTI Club, Gunforce, Gunlock, Hang-On, Hat Trick Hero, Head On, Hidden Catch, House of the Dead, Hunting, Ikari, Initial D, Intrepid, Island, Janputer, Joe & Mac, JoJo's Bizarre Adventure, Jurassic Park, Jurassic Park Pinball, Killer Instinct, Killing Blade, King of Fighters, King of the Monsters, Knights of Valour, Kung-Fu Master, Last Blade, Lethal Enforcers, Lode Runner, Long Hu Bang, Lucky 8 Lines, Magic Card, Magic's 10, Major League, Major Title, Match It, Mario Bros., Marvel Vs. Capcom, Medal Mahjong, Mega Man, Megatouch, Melty Blood, Mobile Suit Gundam, Monaco GP, Monopoly, Moon Cresta, Mortal Kombat, Mr. Driller, Mr. Do!, Multi Champ, Multi Game, NBA Jam, NFL Blitz, Ninja-Kid, Nova 2001, Numan Athletics, Operation Wolf, Oriental Legend, Othello, Out Run, Out Zone, P-47, Pac-Man, Pac-Man Pinball, Paitoride, Pang, ParaParaParadise, Parodius, Phoenix, Photo Y2K, Pinball Action, Pirate Igrosoft, Pit Boss, Pocket Gal, Point Blank, Pole Position, Police Trainer, Pop'n Music, Power Instinct, Power Spikes, Primal Rage, Print Club, Psychic Force, Punch-Out!!, Puzz Loop, Puzzle Bobble, Puzzle-Dama, Q*Bert, Qix, Quarterback, Quiz Tonosama no Yabou, Racin' Force, Rad Mobile, Raiden, Rally X, Rastan, Ridge Racer, Rival Schools, Robin's Adventure, Robocop, Robotron, Rolling Thunder, Samba de Amigo, Samurai Aces, Samurai Shodown, Scramble, SD Gundam, Sega Rally, Sengoku, Shanghai, Sharpshooter Pinball, Shikigami no Shiro, Shinobi, Shock Troopers, Shogun Warriors, Side By Side, Silkroad, Sky Adventure, Sky Kid, Slam Masters, SNK Vs. Capcom, Snow Bros., Sorcer Striker, Soul Edge, Space Harrier, Space Invaders, Special Forces, Spelunker, Sprint, Spy Hunter, Stadium Hero, Star Force, Star Gladiator, Star Wars, Star Wars Arcade, Star Wars Pinball, Steel Gunner, Street Fighter, Street Fighter EX, Strider, Super Real Mahjong, Super Volleyball, Suzuka 8 Hours, Sweet Life, Taisen Hot Gimmick, Tank Battalion, Targ, Tecmo World Cup, Teenage Mutant Ninja Turtles, Tekken, Tetris, Thunder & Lightning, Thunder Cross, Time Crisis, Time Killers, Time Pilot, Touchmaster, Track & Field, Triv, Trivia, Trivia Master, Trivia ? Whiz, Trivial Pursuit, Twin Cobra, TX-1, U.N. Squadron, Vanguard, Vapor Trail, Victor, Violence Fight, Virtua Cop, Virtua Striker, Wangan Midnight, Wonder Boy, World Class Bowling, World Combat, World Stadium, WWF Superstars, Xevious, Zero Gunner, Zero Point.


(C) 2013/2023 AntoPISA progetto-SNAPS