MESSINFO.DAT 0.262  (Feb 16, 2024)
(C) AntoPISA www.progettoSNAPS.net
==================================

WhatsNew:
=========
11.53 02/16/2024: Aligned files to 0.262 version.
11.52 02/09/2024: The file is now available on GitHub; you can find it here: https://github.com/AntoPISA/MAME_SupportFiles
11.52 12/09/2023: Aligned files to 0.261 version.
11.51 11/05/2023: Aligned files to 0.260 version.
11.50 10/12/2023: Aligned files to 0.259 version.
11.49 09/11/2023: Aligned files to 0.258 version.
11.48 08/06/2023: Aligned files to 0.257 version.
11.47 07/12/2023: Aligned files to 0.256 version.
11.46 07/07/2023: Added 12 forgotten devices in version 0.255 (my fault).
11.45 06/18/2023: Aligned files to 0.255 version.
11.44 06/06/2023: Added 60 system descriptions.
11.43 05/09/2023: Aligned files to 0.254 version.
11.42 04/17/2023: Aligned files to 0.253 version.
11.41 03/22/2023: Aligned files to 0.252 version.
11.40 01/12/2023: Aligned files to 0.251 version.
11.39 12/31/2022: Aligned files to 0.250 version.
11.38 11/10/2022: Aligned files to 0.249 version.
11.37 10/14/2022: Aligned files to 0.248 version.
11.36 09/25/2022: Aligned files to 0.247 version.
11.35 08/15/2022: Aligned files to 0.246 version.
11.34 07/28/2022: Aligned files to 0.245 version.
11.33 06/08/2022: Aligned files to 0.244 version.
11.32 05/15/2022: Correction of the list of work done this mounth on the machine (exl100), thanks to the report by Robbbert himself..
11.31 05/12/2022: Aligned files to 0.243 version.
11.30 05/08/2022: Added information of 2 Devices, (ti99_tipi) and (ti99_tipi_atttached), forgotten last month...
11.29 04/11/2022: Aligned files to 0.242 version.
11.28 03/05/2022: Aligned files to 0.241 version.
11.27 03/01/2022: Delete all the entries extracted from the SVN lists, not added by me for years.
11.26 02/12/2022: Aligned files to 0.240 version.
11.25 01/09/2022: Aligned files to 0.239 version.
11.24 11/28/2021: Aligned files to 0.238 version.
11.23 11/02/2021: Aligned files to 0.237 version.
11.22 10/13/2021: Aligned files to 0.236 version.
11.21 09/15/2021: Added 50 descriptions of previously absent machines.
11.20 08/31/2021: Aligned files to 0.235 version.
11.19 08/30/2021: The "SOFTWARE LIST" field has been updated for all machines.
11.18 08/25/2021: Again added the field "DRIVER" and that "DRIVER STATUS" also related to the devices.
11.17 08/20/2021: With a new automatic procedure created by motoschifo, now all machines have the "DRIVER STATUS" field always updated.
11.16 08/05/2021: Aligned files to 0.234 version.
11.15 07/12/2021: Expanded the number of information taken from the official "whatsnew", only for version 0.233. Thanks to Nigel Barnes for the stimulating conversation on MameWorld about this subject. 
11.14 07/09/2021: Aligned files to 0.233 version.
11.13 06/06/2021: Aligned files to 0.232 version.
11.12 05/26/2021: Completed the "changelog.txt" and "alltimesMESS.txt" files.
11.11 05/25/2021: Added all the information from the "whatsnew.txt" file relating to versions from 0.222 to 0.229, absent so far. Also fixed many typos.
11.10 05/19/2021: Completed the "sourcechanges.txt" file.
11.09 05/06/2021: Aligned files to 0.231 version.
11.08 04/06/2021: Aligned files to 0.230 version. All the info on the changes made to the various machines that took place between version 0.222 to 0.229 listed in all whatsnew are still missing.
11.07 04/02/2021: The study for the xml version of messinfo has started (and immediately died as I found out that this is a bitch's idea that I don't want to advertise in any way.)
11.06 03/31/2021: Added information related machines, devices and drivers added in 0.228 and 0.229 version (Internal version only, not released).
11.05 03/25/2021: Aligned files to 0.227 version (Internal version only, not released).
11.04 03/23/2021: Aligned files to 0.226 version (Internal version only, not released).
11.03 03/20/2021: Aligned files to 0.225 version (Internal version only, not released).
11.02 03/15/2021: Aligned files to 0.224 version (Internal version only, not released).
11.01 03/10/2021: Aligned files to 0.223 version (Internal version only, not released).
11.00 03/01/2021: Aligned files to 0.222 version, only info on additional machines, devices and drivers, rename, delete, modified descriptions and manufactures, promoted to working and bugfixes (internal version only, not released).
10.03 05/21/2020: Aligned files to 0.221 version.
10.02 04/09/2020: Aligned files to 0.220 version.
10.01 03/05/2020: Aligned files to 0.219 version.
10.00 02/08/2020: Aligned files to 0.218 version.
 9.15 12/29/2019: Aligned files to 0.217 version.
 9.14 12/23/2019: Added the file 'messinfoREM.dat' to the package with the machines and devices removed from the MESS/MAME.
 9.13 12/15/2019: Added 300 device authors.
 9.12 12/01/2019: Aligned files to 0.216 version.
 9.11 11/20/2919: Published a "git" version, aligned to the MESS of the Nov 18, 2019.
 9.10 11/09/2919: Published a "git" version, aligned to the MESS of the Nov 8, 2019.
 9.09 11/07/2019: Aligned files to 0.215 version.
 9.08 09/29/2019: Aligned files to 0.214 version.
 9.07 09/09/2019: Aligned files to 0.213 version.
 9.06 08/11/2019: Aligned files to 0.212 version.
 9.05 07/09/2019: Aligned files to 0.211 version (version 0.210 was not published due to lack of time, sorry).
 9.04 04/28/2019: Aligned files to 0.209 version.
 9.03 04/02/2019: Aligned files to 0.208 version.
 9.02 03/03/2019: Aligned files to 0.207 version.
 9.01 02/07/2019: Aligned files to 0.206 version.
 9.00 01/18/2019: Added on the page the link to download the file in "git" format, updated about once a week.
 8.16 12/28/2018: Aligned files to 0.205 version.
 8.15 12/25/2018: Fixed 1,051 obsolete device descriptions. Added numerous authors of device drivers and information on the devices themselves.
 8.14 12/16/2018: Fixed 77 machine manufacturers.
 8.13 12/11/2018: Fixed 573 obsolete machine descriptions.
 8.12 12/01/2018: Aligned files to 0.204 version.
 8.11 11/15/2018: Fixed some errors.
 8.10 11/02/2018: Aligned files to 0.203 version.
 8.09 10/01/2018: Aligned files to 0.202 version.
 8.08 09/01/2018: Aligned files to 0.201 version.
 8.07 08/25/2018: 38 wrong entries removed; mostly these are devices renamed in 0.187 version. Added also the authors of 5 drivers.
 8.06 07/30/2018: Aligned files to 0.200 version.
 8.05 07/02/2018: Aligned files to 0.199 version.
 8.04 06/02/2018: Aligned files to 0.198 version.
 8.03 04/29/2018: Aligned files to 0.197 version.
 8.02 04/02/2018: Aligned files to 0.196 version.
 8.01 03/02/2018: Aligned files to 0.195 version.
 8.00 02/04/2018: Aligned files to 0.194 version.
 7.23 12/29/2017: Aligned files to 0.193 version.
 7.22 12/11/2017: Aligned files to 0.192 version.
 7.21 10/30/2017: Aligned files to 0.191 version.
 7.20 10/15/2017: From today I update the file every 4/5 days; thanks to the xml file provided by Ashura-X here http://ashura.mameworld.info/nightlybuilds/mess_builds.html.
 7.19 10/01/2017: Aligned files to 0.190 version.
 7.18 09/23/2017: Completed work on formatting correction, deletion of rom data and finding the version of adding all devices. The file is finally complete!
 7.17 09/06/2017: Fixed some new "DRIVER STATUS".
 7.16 09/05/2017: Aligned files to 0.189 version.
 7.15 08/20/2017: Added versions were are added the device (now up to the 0.160 version) and many error fixed.
 7.14 08/15/2017: Correction continues in file formatting and even removal of ROMs of each machine (now visible by MAME itself).
 7.13 08/01/2017: Aligned files to 0.188 version.
 7.12 07/30/2017: Added versions were are added the device (from version 0.148u1 to 0.148u3).
 7.11 07/27/2017: Start the correction of formatting and use of the blank lines in the file. This job will continue for the next few months.
 7.10 07/04/2017: Aligned files to 0.187 version.
 7.09 06/30/2017: Finished the inversion of "whatsnew.txt" comments. Deleted from the package the "changelog.txt" file (which is now only available on the web page).
 7.08 06/08/2017: Aligned files to 0.186 version.
 7.07 05/01/2017: Aligned files to 0.185 version.
 7.06 04/06/2017: Aligned files to 0.184 version.
 7.05 03/15/2017: Added versions  were are added the device (from version 0.146u1 to 0.148).
 7.04 03/01/2017: Aligned files to 0.183 version.
 7.03 02/15/2017: Added versions were are added the device (from version 0.143u3 - the first with these items - to 0.146).
 7.02 01/31/2017: Aligned files to 0.182 version.
 7.01 01/15/2017: Added all Devices entries (but missing the versions in which they were added).
 7.00 01/04/2017: Aligned files to 0.181 version.
 6.18 12/06/2016: Aligned files to 0.180 version.
 6.17 10/28/2016: Aligned files to 0.179 version.
 6.16 10/03/2016: Aligned files to 0.178 version.
 6.15 09/07/2016: Aligned files to 0.177 version.
 6.14 08/20/2016: Fixed some duplicated entries.
 6.13 08/15/2016: Added dmax8000.cpp, fcisio.cpp, sm7238.cpp and tv990.cpp driver entries (I had forgotten).
 6.12 08/06/2016: Aligned files to 0.176 version.
 6.11 07/09/2016: Aligned files to 0.175 version.
 6.10 06/02/2016: Aligned files to 0.174 version.
 6.09 05/31/2016: Fixed some errors in 0.173 infos.
 6.08 05/07/2016: Aligned files to 0.173 version.
 6.07 04/04/2016: Aligned files to 0.172 version. Updated the SVN until March 30, 2016 (r46892).
 6.06 02/29/2016: Aligned files to 0.171 version. Updated the SVN until February 24, 2016 (r45196).
 6.05 01/31/2016: Aligned files to 0.170 version. Updated the SVN until January 27, 2016 (r44512).
 6.04 01/27/2016: JuLePe fixed some type errors in c900, juicebox, krista2, kristall2, lcmate2 and pc9821v13 information.
 6.03 01/10/2016: Check (by JuLePe) information relating to "Save State" of all drivers and fixed the wrong ones.
 6.02 01/09/2016: Updated information for these systems abc110, bbca, bbcb_de, bbcb_us, bbcbp, bbcbp128 and pro128s by Nigel Barnes and also genesis and h21 from JuLePe.
 6.01 01/04/2016: Aligned files to 0.169 version. Updated the SVN until December 30, 2015 (r43025).
 6.00 01/12/2016: Various corrections suggested by JuLePe: deleted the internal references of the sites [##], 'see the more...', 'see below' and 'see pictures'. Correcting the "?" characters which include: Accented vowels (á, é, í, ó, ú, è, ö, ä, ã, å), Slovakian/Serbian characters (Š, ?, ?, ý), Asian characters (tg16 system), apostrophes (wouldn't, computer's,...), another characters (£ € ¥ ½ ¼ ® ™ µ ° ? ß(German ss) ± ² ³ ...). From now on, the file will be available exclusively in UTF-8 format.
 5.22 12/22/2015: Updated the SVN until December 22, 2015 (r42904).
 5.21 25/11/2015: Aligned files to 0.168 version. Updated the SVN until November 25, 2015 (r41860).
 5.20 11/11/2015: Aligned files to 0.167 version. Updated the SVN until October 28, 2015 (r41413).
 5.19 10/31/2015: End of phase 9, finding all driver authors!
 5.18 10/04/2015: Aligned files to 0.166 version. Updated the SVN until September 30, 2015 (r40959).
 5.17 09/27/2015: Added other authors (97% right).
 5.16 08/29/2015: Aligned files to 0.165 version. Fixed some typos error. Updated the SVN until August 26, 2015 (r40488). Added other authors (93% right); fixed various typo errors.
 5.15 08/26/2015: Updated "messnoinfosets_?.txt" file to 0.165 version.
 5.14 08/15/2015: Fixed typos error in: "alltimesMESS.txt", "changelog.txt" and "sourcechanges.txt" (thanks to Stiletto).
 5.13 07/30/2015: Aligned files to 0.164 version. Updated the SVN until July 29, 2015 (r40040). Added other authors (91% right); fixed various typo errors.
 5.12 06/25/2015: Aligned files to 0.163 version. Updated the SVN until June 24, 2015 (r39030).
 5.11 06/22/2015: Added many authors (86% right); fixed various typo errors.
 5.10 06/21/2015: Updated the SVN until June 21, 2015 (r38709).
 5.09 06/02/2015: Aligned files to 0.162 version. Updated the SVN until May 27, 2015 (r38204). Added many authors (85% right).
 5.08 05/02/2015: Aligned files to 0.161 version. Updated the SVN until April 29, 2015 (r37458).
 5.07 04/26/2015: Added many authors (83% right).
 5.06 04/24/2015: Updated the SVN until April 24, 2015 (r37364).
 5.05 03/29/2015: Aligned files to 0.160 version. Updated the SVN until March 25, 2015 (r36625).
 5.04 03/11/2015: Updated the SVN until March 11, 2015 (r36375).
 5.03 02/26/2015: Aligned files to 0.159 version. Updated the SVN until February 25, 2015 (r35257).
 5.02 02/04/2015: Aligned files to 0.158 version. Updated the SVN until January 28, 2015 (r34635).
 5.01 01/22/2015: Updated the SVN until January 21, 2015 (r34529). Put the information on the machines added after 0.157 release.
 5.00 01/03/2015: Aligned files to 0.157 version (added all new machines with complete infos). Updated the SVN until December 31, 2014 (r34121). Also updated 'Index of Devices'.
 4.27 12/31/2014: Added 'softwarelists' complete xml.
 4.26 12/26/2014: Phase 8 completed! Presence of software lists for all sets (aligned to version 0.156 svn34060).
 4.25 12/24/2014: Completed the file 'changelog.txt' (0.1 to 0.156). Updated the SVN until December 24, 2014 (r34057).
 4.24 12/22/2014: Completed the file 'sourcechanges.txt' (0.1 to 0.156).
 4.23 12/20/2014: Updated the SVN until December 20, 2014 (r33931). Updated presence of software lists (92% right) and 72% of authors finded.
 4.22 11/28/2014: Aligned files to 0.156 version. Updated the SVN until November 26, 2014 (r33555). Updated presence of software lists (64% right). Updated 'Index of Devices'.
 4.21 11/24/2014: Added 'supportedMEDIA' file. Renamed support file 'alltimesMESS_WIP.txt' to 'alltimesMESS.txt'.
 4.20 11/23/2014: Updated the SVN until November 21, 2014 (r33482). Corrected some minor errors.
 4.19 10/18/2014: Aligned files to 0.155 version. Updated the SVN until October 15, 2014 (r31761). Updated presence of software lists (64% right). Updated 'Index of Devices'.
 4.18 10/13/2014: Added many driver set from (msx.c). Updated the SVN until October 13, 2014 (r32705).
 4.17 09/12/2014: Updated the SVN until September 12, 2014 (r32078).
 4.16 07/25/2014: Aligned files to 0.154 version. Updated the SVN until July 23, 2014 (r31396). Updated presence of software lists (56% right). Updated 'Index of Devices'.
 4.15 06/22/2014: Updated the SVN until June 22, 2014 (r31075).
 4.14 06/10/2014: Updated the SVN until June 8, 2014 (r30892).
 4.13 05/29/2014: Updated presence of software lists (49% right) and updated the SVN until May 29, 2014 (r30708). Started the upgrade of the resources available (on my website) for each set (5% right).
 4.12 05/08/2014: Third birthday version! Updated the SVN until May 7, 2014 (r30318); also updated the 'Drivers SVN...txt' and 'version.ini' files.
 4.11 05/04/2014: Updated presence of software lists (42% right) and updated the SVN until May 3, 2014 (r30208).
 4.10 05/01/2014: Phase 7 completed! Compressed set size in kylobytes for all sets (aligned to version 0.153). Updated the SVN until April 22, 2014 (r29849).
 4.09 04/10/2014: Aligned files to 0.153 version. Updated the SVN until April  7, 2014 (r29405). Updated presence of software lists (39% right) and compressed set size in kylobytes (84% right). Updated 'Index of Devices'.
 4.08 03/29/2014: Added (at bottom of file) the 'Index of Devices' aligned to 0.152 version.
 4.07 03/27/2014: Updated compressed set size in kylobytes (72% right).
 4.06 03/22/2014: Updated the SVN until March 20, 2014 (r28767).
 4.05 03/11/2014: Updated the SVN until March 9, 2014 (r28347). Updated presence of software lists (28% right) and compressed set size in kylobytes (65% right).
 4.04 03/02/2014: Updated the SVN until March 1, 2014 (r28160).
 4.03 02/25/2014: Updated presence of software lists (19% right) and compressed set size in kylobytes (32% right). Updated the SVN until February 24, 2014 (r27963).
 4.02 02/22/2014: Updated the SVN until February 22, 2014 (r27906).
 4.01 02/12/2014: Start adding presence of software lists (right from '1292apvs' to 'byte') and reorder compressed set size in kylobytes (right from '1292apvs' to 'berlinp').
 4.00 01/31/2014: Updated the SVN until January 31, 2014 (r27365).
 3.38 12/29/2013: Aligned files to 0.152 version. Updated the SVN until December 24, 2013 (r26737).
 3.37 11/23/2013: Updated the SVN until November 23, 2013 (r26386).
 3.36 11/09/2013: Fixed authors of 0.151 adds (thanks to Nigel Barnes).
 3.35 11/08/2013: Aligned files to 0.151 version. Updated the SVN until November 5, 2013 (r26005).
 3.34 11/01/2013: Various fix in list of drivers and machines.
 3.33 10/21/2013: Updated the SVN until October 21, 2013 (r25769). Added info of 2 new drivers and 10 machines.
 3.32 09/19/2013: Aligned files to 0.150 version. Updated the SVN until September 17, 2013 (r25362).
 3.31 09/04/2013: Updated the SVN until September 4, 2013 (r25212).
 3.30 08/17/2013: Updated the SVN until August 17, 2013 (r24936).
 3.29 07/25/2013: Aligned files to 0.149u1 version. Updated the SVN until July 23, 2013 (r24475).
 3.28 07/09/2013: Updated the SVN until July 9, 2013 (r24145).
 3.27 06/12/2013: Aligned files to 0.149 version. Updated the SVN until June 11, 2013 (r23639).
 3.26 06/01/2013: Updated the SVN until June 1, 2013 (r23359).
 3.25 05/28/2013: Updated the SVN until May 28, 2013 (r23215).
 3.24 05/20/2013: Aligned files to 0.148u5 version. Updated the SVN until May 20, 2013 (r22988).
 3.23 05/18/2013: Fixed some items. Updated the SVN until May 18, 2013 (r22899).
 3.22 05/17/2013: Phase 6 completed! All available resources added (aligned to version 0.148).
 3.21 05/13/2013: Updated the SVN until May 13, 2013 (r22807). Added resources info; 1,934 sets checked, 75% right).
 3.20 05/01/2013: Aligned files to 0.148u4 version. Updated the SVN until April 30, 2013 (r22620).
 3.19 04/28/2013: Updated the SVN until April 28, 2013 (r22589).
 3.18 04/13/2013: Updated the SVN until April 13, 2013 (r22368).
 3.17 04/10/2013: Added info about three new sets added in 0.148u3.
 3.16 04/09/2013: Aligned files to 0.148u3 version. Updated the SVN until April 9, 2013 (r22292).
 3.15 04/06/2013: Updated the SVN until April 6, 2013 (r22246).
 3.14 03/25/2013: Added resources info; 1,500 sets checked, 66% right).
 3.13 03/19/2013: Aligned files to 0.148u2 version. Updated the SVN until March 19, 2013 (r21962).
 3.12 03/11/2013: Fixed 60 STATUS entries. Updated the SVN until March 9, 2013 (r21773). Added resources info; 1,266 sets checked, 57% right).
 3.11 03/04/2013: Updated the SVN until March 4, 2013 (r21572). Added resources info; 1,047 sets checked, 47% right).
 3.10 02/23/2013: Updated the SVN until February 23, 2013 (r21390). Added resources info; 876 sets checked, 40% right).
 3.09 02/19/2013: Updated the SVN until February 19, 2013 (r21180).
 3.08 02/13/2013: Aligned files to 0.148u1 version. Updated the SVN until February 11, 2013 (r20931).
 3.07 02/10/2013: Added resources info; 696 sets checked, 33% right).
 3.06 02/08/2013: Added info about one new set and updated the SVN until February 8, 2013 (r20836).
 3.05 02/01/2013: From today, the file will be released in two encodings (Windows and Unicode) to maintain compatibility with MESSUI and QMC2.
 3.04 01/31/2013: Added resources info; 627 sets checked, 29% right). Added info about two new set and updated the SVN until January 31, 2013 (r20626).
 3.03 01/29/2013: Updated the SVN until January 28, 2013 (r20579).
 3.02 01/23/2013: I finally started to add to messinfo (set to set) the resources available (here http://www.progettosnaps.net/), including: Artwork, Cabinet, Control Panel and Controllers, Flyer and Advertising, Manuals, Marquees and Logos and PCBs. For now we are only 5% (100 sets checked).
 3.01 01/21/2013: Updated the SVN until January 21, 2013 (r20390).
 3.00 01/11/2013: Aligned files to 0.148 stable version. Updated the SVN until January 11, 2013 (r20196).
 2.68 12/28/2012: Updated the SVN until December 27, 2012 (r19871).
 2.67 12/18/2012: Aligned files to 0.147u4 version. Updated the SVN until December 17, 2012 (r19614).
 2.66 12/06/2012: Updated the SVN until December 6, 2012 (r19351).
 2.65 12/04/2012: Added to the compressed size of BIOSes not yet updated.
 2.64 11/19/2012: Aligned files to 0.147u3 version. Updated the SVN until November 19, 2012 (r19032).
 2.63 11/14/2012: Updated the SVN until November 14, 2012 (r18959). 
 2.62 11/12/2012: End of phase 5! Added 299 descriptions and all set are ok. Except for some sets of which I have found useful or verifiable, the list (262 sets) can be found here: http://www.progettosnaps.net/messinfo/messnoinfoset.txt. Who wants to help me complete info contact me!
 2.61 10/30/2012: Aligned files to 0.147u2 version. Updated the SVN until October 30, 2012 (r18777).
 2.60 10/28/2012: Added 253 (!) descriptions of MESS supported systems (1,416 right / 82% [+14%]). Fixed some errors accumulated in the last 5/6 versions.
 2.59 10/26/2012: Updated the SVN until October 26, 2012 (r18717).
 2.58 10/14/2012: All file converted to UTF-8 standard (reported by QMC2). Updated the SVN until October 11, 2012 (r18443).
 2.57 10/09/2012: Aligned files to 0.147u1 version. Updated the SVN until October 8, 2012 (r18354).
 2.56 09/26/2012: Added many descriptions of MESS supported systems (1,163 right / 68% - completed from 'A' to 'N').
 2.55 09/22/2012: Aligned files to 0.147 version. Updated the SVN until September 17, 2012 (r17960).
 2.54 09/17/2012: Correct the list of supported drivers.
 2.53 09/10/2012: Removed, in docs folder, the files: "quoting.txt", "softwarelist.txt"  and "todolist.txt".
 2.52 09/07/2012: Updated the SVN until September 10, 2012 (r17767).
 2.51 09/07/2012: Updated the SVN until September 3, 2012 (r17609).
 2.50 08/23/2012: Updated the SVN until August 27, 2012 (r17496). Deleted from messinfo pack the old SVN file, downloadable here: http://www.progettosnaps.net/messinfo/MESS_SVN_r1-15977_2012-08-20.zip.
 2.49 08/23/2012: Aligned files to 0.146u5 version. Updated the SVN until August 20, 2012 (r15977).
 2.48 08/02/2012: Aligned files to 0.146u4 version. Updated the SVN until July 30, 2012 (r15709).
 2.47 07/23/2012: Updated the SVN until July 23, 2012 (r15648). Added many descriptions of MESS supported systems (1,081 right, 63%).
 2.46 07/16/2012: Aligned files to 0.146u3 version. Updated the SVN until July 15, 2012 (r15605).
 2.45 07/11/2012: Eliminated all unnecessary spaces from the file: this made it sometimes difficult to read the information inside of the front-ends.
 2.44 07/02/2012: Aligned files to 0.146u2 version. Updated the SVN until July 2, 2012 (r15527).
 2.43 06/16/2012: Updated the SVN until June 26, 2012 (r15504). Removed all references to bugs in Bugzilla (no longer active).
 2.42 06/12/2012: Aligned files to 0.146u1 version.
 2.41 06/08/2012: Updated the SVN until June 8, 2012 (r15424). Added many descriptions of MESS supported systems (864 / 51% completed).
 2.40 06/01/2012: Updated the SVN until May 31, 2012 (r15363).
 2.39 05/24/2012: Aligned files to 0.146 version.
 2.38 05/20/2012: Updated the SVN until May 19, 2012 (r15218).
 2.37 05/07/2012: Aligned files to 0.145u8 version. Updated the SVN until May 7, 2012 (r15112).
 2.36 04/24/2012: Aligned files to 0.145u7 version. Updated the SVN until April 24, 2012 (r15022).
 2.35 04/20/2012: Updated the SVN until April 20, 2012 (r14977).
 2.34 04/17/2012: Updated the SVN until April 17, 2012 (r14946).
 2.33 04/13/2012: Updated the SVN until April 13, 2012 (r14904). Added 20 descriptions of MESS supported systems (mk85, mk90, mlf80, mm1m6, mm1m7, mpf1p, mprof3, mpt02, mpu1000, mpu2000, palmz22, pc6001a, pc6001mk2, pc6001sr, pc6601, pc7000, pc8001, pc8001mk2, pc8201a and pc8300).
 2.32 04/11/2012: Added many descriptions of MESS supported systems (apfimag, apfm1000, aplsbon, atmtb2, atom, avigo_de, avigo_es, avigo_fr, avigo_it, cpc300, cpc300e, cpc464, cpc6128f, cpc6128p, cpc6128s, cpc664, crvisio2, hb10p, hb201, hb201p, hb501p, hb75d, hb75p, hbf1, hmg2650, vg8020000, vg8020f, vg8235f, victor, victor9k, vidbrain, videopac, vii, vip, visicom, visor and vixen); we are still missing 1,245 (26% are completed).
 2.31 04/10/2012: Aligned files to 0.145u6 version. Updated the SVN until April 9, 2012 (r14886). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' 'Drivers SVN...txt' and 'version.ini'.
 2.30 04/03/2012: Updated the SVN until April 3, 2012 (r14844). Added many descriptions of MESS supported systems (ibm5140, ibm5150, ibm5155, ibm5160, ibm5170, ibm5550, ibmpcjx, ibmpcjr, instruct, interact, intervsn, intmpt03, intv2, intvecs, intvkbd, intvsrs, inves, iq151, iskr1030m, iskr1031, ivelultr, ixl2000, jaguar, jaguarcd and jet).
 2.29 03/30/2012: Updated the SVN until March 30, 2012 (r14827).
 2.28 03/29/2012: Added to 'sourcechanges.txt' changes from 0.100 to 0.120.
 2.27 03/27/2012: Aligned files to 0.145u5 version. Updated the SVN until March 27, 2012 (r14814).
 2.26 03/23/2012: Updated the SVN until March 23, 2012 (r14795).
 2.25 03/19/2012: Updated 'quotes.txt' and 'softwarelist.txt' files.
 2.24 03/18/2012: Updated 'sourcechanges.txt' file: right from 0.130 to 0.145u4.
 2.23 03/14/2012: Aligned files to 0.145u4 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' 'Drivers SVN...txt' and 'version.ini'.
 2.22 03/16/2012: End of phase 4! All romset datas are present.
 2.21 03/13/2012: Updated the SVN until March 13, 2012 (r14655). Added some romset infos (bytes/# files/packed bytes), now 97% right, I'm almost done...
 2.20 03/06/2012: Updated the SVN until March 6, 2012 (r14699).
 2.19 03/03/2012: Added 30 romset descriptions (19% right).
 2.18 02/28/2012: Aligned files to 0.145u3 version. Updated the SVN until February 28, 2012 (r14652).
 2.17 02/26/2012: Added, in docs folder, the file 'sourcechanges.txt', this file stores all the changes made to the source of the MESS (info from official whatsnew.txt).
 2.16 02/24/2012: Added some romset infos (bytes/# files/packed bytes), now 91% right, from 'A' to 'S'. Changed the internal numbering of the file.
 2.15 02/21/2012: Aligned files to 0.145u1 version, add new systems and drivers, added some romset infos (bytes/# files). Updated the SVN until February 21, 2012 (r14563).
 2.14 02/14/2012: Added, in docs folder, the file 'Drivers SVN nnnnn (0.nnn) yyyymmdd.txt', bringing together in one file all the MESS drivers.
 2.13 02/12/2012: Added some romset infos (bytes/# files/packed bytes), now 84% right, from 'A' to 'R'.
 2.12 02/10/2012: Updated the SVN until February 10, 2012 (r14411). Fixed various 'cosmetic' errors.
 2.11 02/08/2012: Fixed type error ($infoc64n > $info=c64n). Add information about the sets that have all the art files (cabinets, flyers, icons and PCBs): it is only 10 sets (for now).
 2.10 02/07/2012: Aligned files to 0.145 version, add new systems and drivers, added some romset infos (bytes/# files). Updated the SVN until February 7, 2012 (r14374).
 2.09 01/31/2012: Aligned files to 0.144u7 version. Updated the SVN until January 31, 2012 (r14277).
 2.08 01/29/2012: Added some romset infos (bytes/# files/packed bytes), now 74% right.
 2.07 01/19/2012: Added some romset infos (bytes/# files/packed bytes), now 70% right. Updated the SVN until January 19, 2012 (r14089). Added to the web page the link to view the changelog.
 2.06 01/17/2012: Aligned files to 0.144u6 version.
 2.05 01/16/2012: Updated the SVN until January 16, 2012 (r14060). Added some romset infos (bytes/# files/packed bytes).
 2.04 01/11/2012: Added romset infos (bytes/# files/packed bytes) for 0.144u5.
 2.03 01/09/2012: Aligned files to 0.144u4 version. Updated the SVN until January 9, 2012 (r13954).
 2.02 01/07/2012: Fixed some type errors.
 2.01 01/05/2012: Updated the SVN until January 5, 2012 (r13829). Updated "version.ini" with set added in 0.144u3 and 0.144u4.
 2.00 01/02/2012: Added romset infos (bytes/# files/packed bytes) for 0.144u4 sets and fixed some positioning error alphabetical sets.
 1.63 12/26/2011: Aligned files to 0.144u4 version.
 1.62 12/21/2011: Updated the SVN until December 21, 2011 (r13647).
 1.61 12/20/2011: Added romset infos (bytes/# files/packed bytes) for 0.144u3 sets.
 1.60 12/16/2011: Aligned files to 0.144u3 version. Updated the SVN until December 16, 2011 (r13592). Added to "alltimesMESS_WIP.txt" 0.144u3 infos.
 1.59 12/15/2011: Updated the SVN until December 14, 2011 (r13574).
 1.58 12/12/2011: Finally complete the file "alltimesMESS_WIP.txt".
 1.57 12/09/2011: Added some romset infos (bytes/# files/packed bytes). Added to "alltimesMESS_WIP.txt" infos from 0.111 to 0.120.
 1.56 12/07/2011: Aligned files to 0.144u2 version. Updated the SVN until December 6, 2011 (r13486). Added to "alltimesMESS_WIP.txt" 0.144u2 infos.
 1.55 12/03/2011: Added romset infos (bytes/# files/packed bytes) for 0.144u1 sets.
 1.54 11/29/2011: Aligned files to 0.144u1 version. Updated the SVN until November 28, 2011 (r13403). Added to "alltimesMESS_WIP.txt" 0.144 and 0.144u1 infos.
 1.53 11/21/2011: Added romset infos (bytes/# files/packed bytes) for 0.144 sets. Updated the SVN until November 21, 2011 (r13341).
 1.52 11/16/2011: Aligned files to 0.144 version. Updated the SVN until November 16, 2011 (r13277).
 1.51 11/13/2011: Renamed file "allMESS_WIP.txt" to "alltimesMESS_WIP.txt" and extended.
 1.50 11/11/2011: Updated the SVN until November 11, 2011 (r13215). 
 1.49 11/07/2011: Completed file "version.ini" (0.001 to 0.143u9); added many romset (bytes/# files/packed bytes) infos.
 1.48 11/04/2011: Updated the SVN until November 4, 2011 (r13169). 
 1.47 11/03/2011: Update file "sofwarelist.txt" (added juicebox.xml, updated gbcolor.xml, nes.xml and snes.xml). Added some romset infos (bytes/# files/packed bytes).
 1.46 10/31/2011: Added romset infos (bytes/# files/packed bytes) for 0.143u9 sets.
 1.45 10/28/2011: Aligned files to 0.143u9 version. Updated the SVN until October 28, 2011 (r13113).
 1.44 10/27/2011: Added a first version of the file "version.ini"; to put in "folders" of the MESS.
 1.43 10/26/2011: Added romset infos (bytes/# files/packed bytes) for 0.143u8 sets.
 1.42 10/24/2011: Aligned files to 0.143u8 version. Updated the SVN until October 25, 2011 (r13106).
 1.41 10/23/2011: Update file "sofwarelist.txt" (a2600.xml, gameboy.xml, gbcolor.xml, megadriv.xml, nes.xml, sg1000.xml, snes.xml and supracan.xml).
 1.40 10/20/2011: Added many romset (bytes/# files/packed bytes) infos; 55% right.
 1.39 10/17/2011: Extended file "allMESS_WIP.txt"; updated the SVN until October 17, 2011 (r13054).
 1.38 10/12/2011: Aligned files to 0.143u7 version. Updated the SVN until October 12, 2011 (r13031).
 1.37 10/11/2011: Update file "sofwarelist.txt" (coleco.xml, gba.xml, intv.xml, intvecs.xml, megadriv.xml, n64.xml, nes.xml, sg1000.xml, sms.xml and snes.xml).
 1.36 10/07/2011: Updated the SVN until October 7, 2011 (r13001). Added many romset (bytes/# files/packed bytes) infos; 49% right.
 1.35 10/03/2011: Updated the SVN until October 3, 2011 (r12974). Update file "sofwarelist.txt" (lisa.xlm and snes.xml).
 1.34 10/01/2011: Found and reported all sets that do not need roms (now 105); romsets no data, are now 860 (45% done).
 1.33 09/27/2011: Added many romset (bytes/# files/packed bytes) infos; 38% right.
 1.32 09/26/2011: Update file "sofwarelist.txt" (abc1600.xls, intv.xml and snes.xml); updated the SVN until September 26, 2011 (r12938).
 1.31 09/23/2011: Added romset (bytes/# files/packed bytes) infos (0.143u6 sets); extended file "allMESS_WIP.txt".
 1.30 09/22/2011: Aligned files to 0.143u6 version. Updated the SVN until September 22, 2011 (r12913).
 1.29 09/19/2011: Updated the SVN until September 19, 2011 (r12891). Added file "sofwarelist.txt" (in doc folder) which lists all the software currently run by MESS.
 1.28 09/14/2011: Extended file "allMESS_WIP.txt"; added the description of some systems.
 1.27 09/12/2011: Updated the SVN until September 12, 2011 (r12829). Added romset (bytes/# files/packed bytes) infos (0.143u5 sets). Start the job of writing the new file "MESSrenameSET.dat" and "MESSrenameSET.ini". Fixed minor bugs.
 1.26 09/09/2011: Extended file "allMESS_WIP.txt". Added the description of these systems: abc1600, abc80, abc800c, abc800m, abc802, gameboy, gbcolor, intv, samcoupe, sorcerer, snes, specpl3e, ts1000 and ts1500.
 1.25 09/07/2011: Updated the SVN until September 7, 2011 (r12808). Extended file "allMESS_WIP.txt". Aligned file to 0.143u5 version.
 1.24 09/05/2011: Updated the SVN until September 5, 2011 (r12789). Extended file "allMESS_WIP.txt". Added more information about content and size of romsets.
 1.23 09/02/2011: Updated the SVN until September 2, 2011 (r12766). Extended file "allMESS_WIP.txt".
 1.22 08/30/2011: Updated the SVN until August 29, 2011 (r12733). Extended and corrected the file "allMESS_WIP.txt".
 1.21 08/29/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u4: have this information now to 19% of the total.
 1.20 08/26/2011: Aligned file to 0.143u4 version. Fixed some minor errors.
 1.19 08/24/2011: Added to 'docs' directory, the file "allMESS_WIP". That lists, version by version, all the additions and changes made; it is a pre-pre-release with only 7 MESS examined (the first 3 and last 4).
 1.18 08/23/2011: Updated the SVN until August 23, 2011 (r12700). Added information about content and size of the added or updated BIOS of MESS 0.143u3.
 1.17 08/18/2011: Updated the SVN until August 17, 2011 (r12654).
 1.16 08/17/2011: Aligned file to 0.143u3 version.
 1.15 08/12/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u2.
 1.14 08/11/2011: Added the info taken from the SVN (from 1 to 11890): end of phase 2 (until July 5, 2011). Fixed some errors.
 1.13 07/28/2011: Aligned file to 0.143u2 version.
 1.12 07/20/2011: Added info about 0.135 version.
 1.11 07/18/2011: Added info about versions 0.132, 0.133 and 0.134.
 1.10 07/17/2011: Added info about 0.131 version.
 1.09 07/15/2011: Added info about versions 0.128, 0.129 and 0.130.
 1.08 07/13/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u1.
 1.07 07/12/2011: Aligned file to 0.143u1 version; added info about versions 0.126.
 1.06 07/11/2011: Added info about versions 0.123, 0.124, 0.125. Added file "quoting.txt" to pack.
 1.05 07/08/2011: Added info about versions 0.115, 0.116, 0.117, 0.118, 0.119, 0.120, 0.121 and 0.122. The file is now at 90%.
 1.04 07/07/2011: Added info about 0.114 version; added info of romsets data (from "a5105" to "a800xl").
 1.03 07/06/2011: Added the info taken from the SVN (from 11891 to 12161 - July 5, 20111). Added info about versions 0.112 and 0.113.
 1.02 07/05/2011: Added information about content and size of the added or updated BIOS from MESS 0.142 to 0.143. Added info about versions 0.109, 0.110 and 0.111.
 1.01 07/04/2011: Added info about versions 0.104, 0.105, 0.106, 0.107 and 0.108.
 1.00 06/29/2011: Aligned file to 0.143 version. MESSINFO.DAT online!!!
 0.38 06/28/2011: Added info about versions 0.94, 0.95, 0.96, 0.97, 0.98, 0.99 and 0.100 (35 still missing it!).
 0.37 06/27/2011: Added info about 12 versions (0.82, 0.83, 0.84, 0.85, 0.86, 0.87, 0.88, 0.89, 0.90, 0.91, 0.92 and 0.93!). Added the info taken from the SVN (from 11298 to 11374).
 0.36 06/24/2011: Added info about version 0.132 (a big update with 198 systems added!).
 0.35 06/23/2011: Start adding info of romsets data (from "1292apvs" to "a500p").
 0.34 06/22/2011: Defined the package to be put online, with a zip to an internal self-extracting 7zip, containing: the messinfo.dat file and one folder doc (with history, todo-list and also the textual version of the SVN).
 0.33 06/21/2011: Added info about versions 0.79, 0.80 and 0.81. I thought I would add, in the bottom of each set, as well as the size and number of files that make up each romset, even the contents of the zip themselves the names of the roms, size and CRC32).
 0.32 06/20/2011: Aligned messinfo.dat to 0.142u6 version.
 0.31 06/17/2011: Added info about versions 0.71, 0.72, 0.73, 0.74, 0.77 and 0.78 (now 56% are right!).
 0.30 06/15/2011: Added info about versions 0.62.1, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69 and 0.70. Added the info taken from the SVN (from 11375 to 11684). Small correction to web page logo.
 0.29 06/14/2011: Added info about versions 0.61, 0.61.1, 0.61.2 and 0.62. The file is now at 47%! End check od drivers presence in messinfo.
 0.28 06/13/2011: Added info about version 0.137.
 0.27 06/12/2011: Added the info taken from the SVN (from 11684 to 11545). Checking for drivers in messinfo: completed from 'K' to 'O' (106 will remain to be verified).
 0.26 06/11/2011: Added info about versions 0.56 and 0.56.1. The file is now at 30%.
 0.25 06/10/2011: Translated into english the history file (which becomes the default language). Added info about 0.37b15 version. Added the info taken from the SVN (from 11685 to 11891).
 0.24 06/09/2011: Fixed some errors. Completely rewritten the page with a graphic style inspired by "mess.org".
 0.23 06/08/2011: Cleanup releases list (added unreleased versions). Added info regarding versions 0.37b12 and 0.37b13. Checking MESS drivers present in messinfo: completed from 'D' to 'J'.
 0.22 06/07/2011: Aligned messinfo.dat to 0.142u5 version; correct web page, new and final logo and moved the file on my site, there are still some links to fix. Checking for drivers in messinfo: completed from 'A' to 'C'.
 0.21 06/06/2011: Before writing this file dedicated to the historical progress of the project messinfo.dat (currently only in italian).
 0.20 06/05/2011: Added info about versions 0.37b10, 0.37b11 and 0138. First draft of the website to put online (the logo is provisional).
 0.15 06/02/2011: Fixed various errors. Started on the introduction of the BIOS Zip file sizes (from 32x to a130xe).
 0.14 05/31/2011: Added info about 0.142u4 version; added renamed sets from version 0.138 to 0.142u4.
 0.13 05/29/2011: Added info about 0.139 version. Completed the introductory summary.
 0.12 05/28/2011: Added info about versions 0.37b8 and 0.37b9. Update the data in the introductory summary.
 0.11 05/27/2011: Added info about versions 0.37b5, 0.37b6 and 0.37b7.
 0.10 05/26/2011: Added info about versions 0.37b3 and 0.37b4. Update the data in the introductory summary.
 0.09 05/24/2011: Added info about versions 0.36b13 and 0.36b14.
 0.08 05/23/2011: Added info about versions 0.36b15, 0.36b16, 0.36RC1 and 0.36RC2, corrected some mistakes. Update the data in the introductory summary.
 0.07 05/22/2011: Added info about versions 0.36b13 and 0.36b14.
 0.06 05/20/2011: Added info about versions 0.36b11, 0.36b12 and 0.140. Fixed various errors.
 0.05 05/19/2011: Added info about versions 0.36b6, 0.36b7, 0.36b8 and 0.141. Update the data in the introductory summary.
 0.04 05/16/2011: The file (only for backup and debug) is online at mameworld.info.
 0.03 05/14/2011: Modified again the file structure (standardized to mameinfo.dat) added informations of the last issued MESS (from 0.142 to 0.142u3).
 0.02 05/12/2011: Several corrections to the structure and syntax of the file (thanks to Fabio Priuli); added informations of the first three releases MESS (info on source/whatsnew).
 0.01 05/11/2011: First version of the file (using the 'print to file' a report generated from a table of Microsoft Access) using the systems in MESS 0.142.
 0.00 05/08/2011: He was born the idea for this new MESS project, drawing inspiration from mameinfo.dat of MASH.


(C) 2011/2024 AntoPISA